CREATE DATABASE IF NOT EXISTS SexShop;

USE SexShop;

CREATE TABLE usuario(
  id_usuario INT(5) PRIMARY KEY AUTO_INCREMENT,
  nombre VARCHAR(100),
  email VARCHAR(150),
  contraseña VARCHAR(255),
  direccion VARCHAR(150),
  telefono VARCHAR(15),
  rol ENUM('usuario','administrador') NOT NULL DEFAULT 'usuario'
);

CREATE TABLE producto(
  id_producto INT(5) PRIMARY KEY AUTO_INCREMENT,
  nombre VARCHAR(50),
  descripcion VARCHAR(255),
  precio DECIMAL(10, 2),
  stock INT(10),
  marca VARCHAR(50),
  categoria VARCHAR(50),
  imagen VARCHAR(255),
  id_usuario INT(5),
  FOREIGN KEY (id_usuario) REFERENCES usuario(id_usuario)
);

CREATE TABLE pedido (
  id_pedido INT(5) PRIMARY KEY AUTO_INCREMENT,
  fecha DATE,
  estado VARCHAR(50) DEFAULT 'pendiente',
  total DECIMAL(10, 2),
  id_usuario INT(5),
  FOREIGN KEY (id_usuario) REFERENCES usuario(id_usuario)
);

CREATE TABLE detalle_pedido (
  id_detalle INT(5) PRIMARY KEY AUTO_INCREMENT,
  id_pedido INT(5),
  id_producto INT(5),
  cantidad INT(3),
  precio_unitario DECIMAL(10, 2),
  FOREIGN KEY (id_pedido) REFERENCES pedido(id_pedido),
  FOREIGN KEY (id_producto) REFERENCES producto(id_producto)
);

CREATE TABLE pago(
    monto DECIMAL(10, 2),
    metodo VARCHAR(20),
    fecha DATE,
    id_pedido INT(5),
    FOREIGN KEY (id_pedido) REFERENCES pedido(id_pedido)
);


INSERT INTO usuario (nombre, email, contraseña, direccion, telefono, rol) VALUES 
('Eljefe', 'admin@SexShop.com', '75321', 'Calle de los chamos 123', '1234567890', 'administrador'),
('Oswal', 'oseal@gmail.com', '123456', 'Calle de los chamos 123', '7532145', 'administrador'),
('federico Gutierrez', 'Fede@gmail.com', '78963', 'Calle calera ', '0987654321', 'usuario');

INSERT INTO producto (nombre, descripcion, precio, stock, marca, categoria, imagen, id_usuario) VALUES 
('Lubricante hot ice', 'Para aumentar la sensacion en casa', 16.500, 50, 'Lorem', 'lubricantes', 'Lubricante1.png', 1),
('Lubricante Lima', 'Sensacion de acides', 15.999, 30, 'Chamoi', 'lubricantes', 'Lubricante2.png', 1),
('Lubricante cereza', 'Sensacion de power', 18.999, 10, 'lamor', 'lubricantes', 'Lubricante3.png', 1),
('Lubricante mango', 'Sensacion de dulce', 17.999, 20, 'caral', 'lubricantes', 'Lubricante4.png', 1),
('Lenceria mamalona', 'te hace ver re diva', 75.999, 40, 'Adidas', 'lenceria', 'Lenceria1.png', 1),
('Lenceria Potro', 'te hace ver re diva', 75.999, 40, 'Adidas', 'lenceria', 'Lenceria2.png', 1),
('Lenceria MikeyMause', 'te hace ver re diva', 76.999, 40, 'Adidas', 'lenceria', 'Lenceria3.png', 1),
('Lenceria matriz', 'te hace ver re diva', 80.999, 20, 'Adidas', 'lenceria', 'Lenceria4.png', 1),
('Dildo 4 Velocidades', 'para hacerte bibrar hasta el *', 79.999, 20, 'xds', 'juguetes', 'Producto1.png', 1),
('Dildo OswalCasa', 'Para este es de 16 cm x 4 Cm + plus de 5 velocidades', 77.999, 10, 'tetative', 'juguetes', 'Producto2.png', 1),
('Dildo Contestura 4 En uno', 'Brinca maldita puelca', 88.999, 50, 'Cahetive', 'juguetes', 'Producto3.png', 1),
('Dildo 4 Velocidades', 'para hacerte bibrar hasta el *', 77.999, 30, 'Adidas', 'juguetes', 'Producto4.png', 1);
