import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';
import ApiService from '../services/api';
import { showSuccess, showError } from '../utils/notifications';

const Cart = () => {
  const { 
    cartItems, 
    removeFromCart, 
    updateQuantity, 
    clearCart, 
    getCartTotal, 
    getOrderData 
  } = useCart();
  const { user, isAuthenticated } = useAuth();
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  console.log('🛒 Cart Component - Datos del carrito:', {
    cartItems,
    cartItemsLength: cartItems?.length,
    isAuthenticated: isAuthenticated(),
    user: user
  });

  const handleQuantityChange = (productId, newQuantity) => {
    if (newQuantity < 1) {
      removeFromCart(productId);
    } else {
      updateQuantity(productId, newQuantity);
    }
  };

  const handleFinalizePurchase = async () => {
    if (!user) {
      showError('💋 Debes iniciar sesión para finalizar tu compra sensual');
      return;
    }

    setLoading(true);
    try {
      const orderData = getOrderData(user.id);
      const response = await ApiService.createOrder(orderData);
      
      if (response.success) {
        showSuccess('✨ ¡Pedido realizado exitosamente! Prepárate para disfrutar');
        clearCart();
        navigate('/');
      }
    } catch (error) {
      console.error('Error al crear pedido:', error);
      if (error.message.includes('Stock insuficiente')) {
        showError('💔 Stock insuficiente para algunos productos', 'STOCK_ERROR');
      } else {
        showError('💫 Error al procesar el pedido', error.type || 'ORDER_ERROR');
      }
    } finally {
      setLoading(false);
    }
  };

  // SIEMPRE mostrar algo, independientemente del estado
  return (
    <div className="section" style={{ minHeight: '80vh', paddingTop: '120px' }}>
      <div className="container">
        <h1 className="section-title white sparkle">
          🛒 Tu Carrito de Deseos
        </h1>

        {/* Panel de debug - estilo sensual */}
        <div style={{
          background: 'rgba(26, 10, 26, 0.6)',
          border: '1px solid rgba(255, 20, 147, 0.3)',
          padding: '1.5rem',
          borderRadius: '15px',
          marginBottom: '2rem',
          fontSize: '0.9rem',
          backdropFilter: 'blur(10px)',
          color: '#ff69b4'
        }}>
          <p><strong style={{ color: '#ff1493' }}>👤 Usuario:</strong> {user ? user.name : 'Invitado sensual'}</p>
          <p><strong style={{ color: '#ff1493' }}>🛍️ Items en carrito:</strong> {cartItems ? cartItems.length : 'undefined'}</p>
          {cartItems && cartItems.length > 0 && (
            <div>
              <strong style={{ color: '#ff1493' }}>💎 Productos sensuales:</strong>
              <ul style={{ marginLeft: '1rem', marginTop: '0.5rem' }}>
                {cartItems.map(item => (
                  <li key={item.id_producto} style={{ color: '#fff', marginBottom: '0.3rem' }}>
                    {item.nombre} - Cantidad: {item.cantidad}
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>

        {/* Verificar autenticación */}
        {!isAuthenticated() ? (
          <div className="card glow-effect" style={{ maxWidth: '600px', margin: '0 auto', textAlign: 'center' }}>
            <div style={{ fontSize: '4rem', marginBottom: '1rem' }}>💋</div>
            <h2 style={{ 
              color: '#ff69b4', 
              marginBottom: '1rem',
              fontSize: '2rem',
              background: 'linear-gradient(45deg, #ff1493, #ff69b4)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent'
            }}>
              Acceso Exclusivo Requerido
            </h2>
            <p style={{ color: '#fff', marginBottom: '2rem', fontSize: '1.1rem' }}>
              💖 Para acceder a tu carrito de deseos y realizar compras sensuales, necesitas iniciar sesión en tu cuenta VIP.
            </p>
            <Link to="/login" className="btn btn-primary sparkle" style={{ fontSize: '1.1rem', padding: '1rem 2rem' }}>
              💕 Iniciar Sesión VIP
            </Link>
          </div>
        ) : !cartItems || cartItems.length === 0 ? (
          /* Carrito vacío */
          <div className="card glow-effect" style={{ maxWidth: '600px', margin: '0 auto', textAlign: 'center' }}>
            <div style={{ fontSize: '4rem', marginBottom: '1rem' }}>🛒</div>
            <h2 style={{ 
              color: '#ff69b4', 
              marginBottom: '1rem',
              fontSize: '2rem',
              background: 'linear-gradient(45deg, #ff1493, #ff69b4)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent'
            }}>
              Tu Carrito de Deseos está Vacío
            </h2>
            <p style={{ color: '#fff', marginBottom: '2rem', fontSize: '1.1rem' }}>
              ✨ ¡Explora nuestra colección sensual y agrega productos irresistibles a tu carrito!
            </p>
            <Link to="/products" className="btn btn-primary sparkle" style={{ fontSize: '1.1rem', padding: '1rem 2rem' }}>
              🛍️ Explorar Productos Sensuales
            </Link>
          </div>
        ) : (
          /* Carrito con productos */
          <div style={{ 
            display: 'grid', 
            gridTemplateColumns: window.innerWidth <= 768 ? '1fr' : '1fr 350px', 
            gap: '2rem' 
          }}>
            {/* Lista de productos */}
            <div>
              <h3 style={{ 
                color: '#ff69b4', 
                marginBottom: '1.5rem',
                fontSize: '1.5rem',
                textAlign: 'center'
              }}>
                💖 Productos en tu Carrito Sensual ({cartItems.length})
              </h3>
              
              {cartItems.map(item => (
                <div key={item.id_producto} className="card" style={{ marginBottom: '1.5rem' }}>
                  <div style={{ 
                    display: 'grid', 
                    gridTemplateColumns: window.innerWidth <= 768 ? '1fr' : '120px 1fr auto', 
                    gap: '1.5rem', 
                    alignItems: 'center' 
                  }}>
                    {/* Imagen del producto */}
                    <div style={{
                      width: window.innerWidth <= 768 ? '100%' : '100px',
                      height: '100px',
                      background: 'linear-gradient(45deg, rgba(255, 20, 147, 0.1), rgba(255, 105, 180, 0.1))',
                      border: '2px solid rgba(255, 20, 147, 0.3)',
                      borderRadius: '15px',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      fontSize: '2rem',
                      margin: window.innerWidth <= 768 ? '0 auto' : '0'
                    }}>
                      <img 
                        src={`/images/${item.imagen}`} 
                        alt={item.nombre}
                        style={{ 
                          width: '80px', 
                          height: '80px', 
                          objectFit: 'cover', 
                          borderRadius: '10px' 
                        }}
                        onError={(e) => { 
                          e.target.style.display = 'none'; 
                          e.target.nextSibling.style.display = 'block'; 
                        }}
                      />
                      <span style={{ display: 'none' }}>💎</span>
                    </div>

                    {/* Información del producto */}
                    <div style={{ textAlign: window.innerWidth <= 768 ? 'center' : 'left' }}>
                      <h4 style={{ 
                        color: '#ff69b4', 
                        marginBottom: '0.8rem',
                        fontSize: '1.3rem'
                      }}>
                        {item.nombre}
                      </h4>
                      <p style={{ 
                        color: '#fff', 
                        fontSize: '0.95rem', 
                        marginBottom: '0.8rem',
                        opacity: 0.9
                      }}>
                        {item.descripcion}
                      </p>
                      <p style={{ 
                        color: '#ff69b4', 
                        fontSize: '0.9rem', 
                        marginBottom: '0.8rem'
                      }}>
                        <strong>🏷️ Marca:</strong> {item.marca} | <strong>📦 Stock:</strong> {item.stock}
                      </p>
                      <div style={{ 
                        fontSize: '1.4rem', 
                        fontWeight: 'bold', 
                        background: 'linear-gradient(45deg, #ff1493, #ff69b4)',
                        WebkitBackgroundClip: 'text',
                        WebkitTextFillColor: 'transparent'
                      }}>
                        ${parseFloat(item.precio).toFixed(2)} c/u
                      </div>
                    </div>

                    {/* Controles */}
                    <div style={{ 
                      textAlign: 'center', 
                      minWidth: '120px',
                      margin: window.innerWidth <= 768 ? '1rem auto 0' : '0'
                    }}>
                      <div style={{ 
                        display: 'flex', 
                        alignItems: 'center', 
                        gap: '0.8rem', 
                        marginBottom: '1.2rem',
                        justifyContent: 'center'
                      }}>
                        <button
                          onClick={() => handleQuantityChange(item.id_producto, item.cantidad - 1)}
                          style={{
                            width: '40px',
                            height: '40px',
                            borderRadius: '50%',
                            border: '2px solid #ff1493',
                            background: 'rgba(26, 10, 26, 0.8)',
                            color: '#ff1493',
                            cursor: 'pointer',
                            fontSize: '1.5rem',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            transition: 'all 0.3s ease',
                            fontWeight: 'bold'
                          }}
                          onMouseOver={(e) => {
                            e.target.style.background = 'rgba(255, 20, 147, 0.2)';
                            e.target.style.transform = 'scale(1.1)';
                          }}
                          onMouseOut={(e) => {
                            e.target.style.background = 'rgba(26, 10, 26, 0.8)';
                            e.target.style.transform = 'scale(1)';
                          }}
                        >
                          -
                        </button>
                        <span style={{ 
                          minWidth: '40px', 
                          textAlign: 'center', 
                          fontSize: '1.3rem', 
                          fontWeight: 'bold',
                          color: '#ff69b4',
                          background: 'rgba(255, 105, 180, 0.1)',
                          padding: '0.5rem',
                          borderRadius: '10px',
                          border: '1px solid rgba(255, 105, 180, 0.3)'
                        }}>
                          {item.cantidad}
                        </span>
                        <button
                          onClick={() => handleQuantityChange(item.id_producto, item.cantidad + 1)}
                          disabled={item.cantidad >= item.stock}
                          style={{
                            width: '40px',
                            height: '40px',
                            borderRadius: '50%',
                            border: '2px solid #ff1493',
                            background: item.cantidad >= item.stock ? 'rgba(100, 100, 100, 0.5)' : 'rgba(26, 10, 26, 0.8)',
                            color: item.cantidad >= item.stock ? '#999' : '#ff1493',
                            cursor: item.cantidad >= item.stock ? 'not-allowed' : 'pointer',
                            fontSize: '1.5rem',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            transition: 'all 0.3s ease',
                            fontWeight: 'bold'
                          }}
                          onMouseOver={(e) => {
                            if (item.cantidad < item.stock) {
                              e.target.style.background = 'rgba(255, 20, 147, 0.2)';
                              e.target.style.transform = 'scale(1.1)';
                            }
                          }}
                          onMouseOut={(e) => {
                            if (item.cantidad < item.stock) {
                              e.target.style.background = 'rgba(26, 10, 26, 0.8)';
                              e.target.style.transform = 'scale(1)';
                            }
                          }}
                        >
                          +
                        </button>
                      </div>
                      
                      <div style={{ 
                        fontSize: '1.3rem', 
                        fontWeight: 'bold', 
                        marginBottom: '1.2rem',
                        color: '#ff1493',
                        background: 'rgba(255, 20, 147, 0.1)',
                        padding: '0.5rem',
                        borderRadius: '10px',
                        border: '1px solid rgba(255, 20, 147, 0.3)'
                      }}>
                        💰 ${(item.precio * item.cantidad).toFixed(2)}
                      </div>

                      <button
                        onClick={() => removeFromCart(item.id_producto)}
                        className="btn btn-danger"
                        style={{ 
                          padding: '0.5rem 1.2rem', 
                          fontSize: '0.9rem',
                          width: window.innerWidth <= 768 ? '100%' : 'auto'
                        }}
                      >
                        🗑️ Eliminar
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Resumen del pedido */}
            <div>
              <div className="card glow-effect" style={{ 
                position: window.innerWidth <= 768 ? 'relative' : 'sticky', 
                top: '120px',
                marginTop: window.innerWidth <= 768 ? '2rem' : '0'
              }}>
                <h3 style={{ 
                  color: '#ff69b4', 
                  marginBottom: '2rem',
                  textAlign: 'center',
                  fontSize: '1.6rem'
                }}>
                  💎 Resumen de tu Compra Sensual
                </h3>
                
                <div style={{ marginBottom: '2rem' }}>
                  <div style={{ 
                    display: 'flex', 
                    justifyContent: 'space-between', 
                    marginBottom: '1rem',
                    padding: '0.8rem',
                    background: 'rgba(255, 105, 180, 0.1)',
                    borderRadius: '10px',
                    border: '1px solid rgba(255, 105, 180, 0.2)'
                  }}>
                    <span style={{ color: '#fff', fontSize: '1.1rem' }}>
                      🛍️ Productos ({cartItems.length}):
                    </span>
                    <span style={{ color: '#ff1493', fontWeight: 'bold', fontSize: '1.1rem' }}>
                      ${getCartTotal().toFixed(2)}
                    </span>
                  </div>
                  <div style={{ 
                    display: 'flex', 
                    justifyContent: 'space-between', 
                    marginBottom: '1rem',
                    padding: '0.8rem',
                    background: 'rgba(138, 43, 226, 0.1)',
                    borderRadius: '10px',
                    border: '1px solid rgba(138, 43, 226, 0.2)'
                  }}>
                    <span style={{ color: '#fff', fontSize: '1.1rem' }}>🚚 Envío discreto:</span>
                    <span style={{ color: '#8a2be2', fontWeight: 'bold', fontSize: '1.1rem' }}>
                      ✨ Gratis
                    </span>
                  </div>
                  <hr style={{ 
                    margin: '1.5rem 0', 
                    border: 'none',
                    height: '2px',
                    background: 'linear-gradient(90deg, #ff1493, #ff69b4, #da70d6)'
                  }} />
                  <div style={{ 
                    display: 'flex', 
                    justifyContent: 'space-between', 
                    fontSize: '1.5rem', 
                    fontWeight: 'bold',
                    padding: '1rem',
                    background: 'rgba(255, 20, 147, 0.1)',
                    borderRadius: '15px',
                    border: '2px solid rgba(255, 20, 147, 0.3)'
                  }}>
                    <span style={{ color: '#ff69b4' }}>💖 Total:</span>
                    <span style={{ 
                      background: 'linear-gradient(45deg, #ff1493, #ff69b4)',
                      WebkitBackgroundClip: 'text',
                      WebkitTextFillColor: 'transparent'
                    }}>
                      ${getCartTotal().toFixed(2)}
                    </span>
                  </div>
                </div>

                <button
                  onClick={handleFinalizePurchase}
                  disabled={loading}
                  className="btn btn-success sparkle"
                  style={{ 
                    width: '100%', 
                    marginBottom: '1rem',
                    opacity: loading ? 0.7 : 1,
                    fontSize: '1.1rem',
                    padding: '1rem'
                  }}
                >
                  {loading ? (
                    <span style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.8rem' }}>
                      <div className="loading"></div>
                      ⏳ Procesando tu Deseo...
                    </span>
                  ) : (
                    '✨ Finalizar Compra Sensual'
                  )}
                </button>

                <button
                  onClick={clearCart}
                  className="btn btn-secondary"
                  style={{ width: '100%', fontSize: '1rem' }}
                >
                  🗑️ Vaciar Carrito
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Cart;