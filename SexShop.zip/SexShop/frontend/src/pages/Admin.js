import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import ApiService from '../services/api';
import { showSuccess, showError } from '../utils/notifications';

const Admin = () => {
  const { user, isAdmin } = useAuth();
  const [activeTab, setActiveTab] = useState('products');
  const [products, setProducts] = useState([]);
  const [users, setUsers] = useState([]);
  const [orders, setOrders] = useState([]);
  const [userStats, setUserStats] = useState({});
  const [loading, setLoading] = useState(false);
  const [showProductForm, setShowProductForm] = useState(false);
  const [editingProduct, setEditingProduct] = useState(null);
  const [productForm, setProductForm] = useState({
    nombre: '',
    descripcion: '',
    precio: '',
    stock: '',
    marca: '',
    categoria: 'lenceria',
    imagen: ''
  });

  useEffect(() => {
    if (isAdmin()) {
      if (activeTab === 'products') loadProducts();
      if (activeTab === 'users') loadUsers();
      if (activeTab === 'orders') loadOrders();
    }
  }, [activeTab]);

  if (!isAdmin()) {
    return (
      <div className="section">
        <div className="container" style={{ textAlign: 'center', color: '#ff69b4', paddingTop: '120px' }}>
          <div style={{
            background: 'rgba(26, 10, 26, 0.8)',
            border: '2px solid #ff1493',
            borderRadius: '20px',
            padding: '3rem',
            backdropFilter: 'blur(15px)',
            boxShadow: '0 20px 40px rgba(255, 20, 147, 0.3)'
          }}>
            <h2 style={{
              fontSize: '2.5rem',
              background: 'linear-gradient(45deg, #ff1493, #ff69b4)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              marginBottom: '1rem'
            }}>
              🚫 Acceso Denegado
            </h2>
            <p style={{ fontSize: '1.2rem', color: '#ff69b4' }}>
              💎 Solo los administradores pueden acceder a esta área exclusiva
            </p>
          </div>
        </div>
      </div>
    );
  }

  const loadProducts = async () => {
    setLoading(true);
    try {
      const response = await ApiService.getProducts();
      if (response.success) {
        setProducts(response.products);
      }
    } catch (error) {
      showError('Error al cargar productos', error.type);
    } finally {
      setLoading(false);
    }
  };

  const handleProductSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      const productData = {
        ...productForm,
        precio: parseFloat(productForm.precio),
        stock: parseInt(productForm.stock),
        id_usuario: user.id
      };

      let response;
      if (editingProduct) {
        response = await ApiService.updateProduct(editingProduct.id_producto, productData);
      } else {
        response = await ApiService.createProduct(productData);
      }

      if (response.success) {
        showSuccess(editingProduct ? 'Producto actualizado' : 'Producto creado');
        setShowProductForm(false);
        setEditingProduct(null);
        setProductForm({
          nombre: '', descripcion: '', precio: '', stock: '', marca: '', categoria: 'lenceria', imagen: ''
        });
        loadProducts();
      }
    } catch (error) {
      showError('Error al guardar producto', error.type);
    } finally {
      setLoading(false);
    }
  };

  const handleEditProduct = (product) => {
    setEditingProduct(product);
    setProductForm({
      nombre: product.nombre,
      descripcion: product.descripcion,
      precio: product.precio.toString(),
      stock: product.stock.toString(),
      marca: product.marca,
      categoria: product.categoria,
      imagen: product.imagen
    });
    setShowProductForm(true);
  };

  const handleDeleteProduct = async (id) => {
    if (!window.confirm('💋 ¿Estás seguro de que quieres eliminar este producto sensual?')) return;
    
    try {
      const response = await ApiService.deleteProduct(id);
      if (response.success) {
        showSuccess('Producto eliminado');
        loadProducts();
      }
    } catch (error) {
      showError('Error al eliminar producto', error.type);
    }
  };

  const loadUsers = async () => {
    setLoading(true);
    try {
      const response = await ApiService.getUsers();
      if (response.success) {
        setUsers(response.users);
        
        const stats = {};
        for (const userItem of response.users) {
          try {
            const userStatsResponse = await ApiService.getUserStats(userItem.id_usuario);
            if (userStatsResponse.success) {
              stats[userItem.id_usuario] = userStatsResponse.stats;
            }
          } catch (error) {
            console.error('Error al cargar stats del usuario:', error);
          }
        }
        setUserStats(stats);
      }
    } catch (error) {
      showError('Error al cargar usuarios', error.type);
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteUser = async (id, userName) => {
    const stats = userStats[id];
    
    let confirmMessage = `💔 ¿Estás seguro de que quieres eliminar al usuario "${userName}"?`;
    
    if (stats && (stats.products > 0 || stats.orders > 0)) {
      confirmMessage += `\n\n⚠️ ATENCIÓN: Esta acción eliminará PERMANENTEMENTE:\n`;
      if (stats.products > 0) confirmMessage += `- ${stats.products} producto(s) creado(s) por este usuario\n`;
      if (stats.orders > 0) confirmMessage += `- ${stats.orders} pedido(s) realizado(s) por este usuario\n`;
      confirmMessage += `\n¿Continuar con la eliminación en cascada?`;
    }
    
    if (!window.confirm(confirmMessage)) return;
    
    try {
      const response = await ApiService.deleteUser(id);
      if (response.success) {
        showSuccess(response.message);
        loadUsers();
        
        if (response.deleted && response.deleted.products > 0) {
          loadProducts();
        }
        
        if (response.deleted && response.deleted.orders > 0) {
          loadOrders();
        }
      }
    } catch (error) {
      if (error.type === 'LAST_ADMIN_ERROR') {
        showError(error.message, 'LAST_ADMIN_ERROR');
      } else {
        showError('Error al eliminar usuario', error.type);
      }
    }
  };

  const handleChangeUserRole = async (id, newRole) => {
    try {
      const response = await ApiService.updateUserRole(id, newRole);
      if (response.success) {
        showSuccess(response.message);
        loadUsers();
      }
    } catch (error) {
      if (error.type === 'LAST_ADMIN_ERROR') {
        showError(error.message, 'LAST_ADMIN_ERROR');
      } else {
        showError('Error al actualizar rol', error.type);
      }
    }
  };

  const loadOrders = async () => {
    setLoading(true);
    try {
      const response = await ApiService.getAllOrders();
      if (response.success) {
        setOrders(response.orders);
      }
    } catch (error) {
      showError('Error al cargar pedidos', error.type);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="section" style={{ paddingTop: '120px' }}>
      <div className="container">
        <h1 className="section-title white sparkle">
          💎 Panel de Administración Exclusivo
        </h1>

        {/* Tab Navigation */}
        <div style={{
          background: 'rgba(26, 10, 26, 0.8)',
          border: '1px solid rgba(255, 20, 147, 0.3)',
          borderRadius: '20px',
          padding: '1.5rem',
          marginBottom: '2rem',
          backdropFilter: 'blur(15px)',
          boxShadow: '0 10px 30px rgba(0, 0, 0, 0.3)'
        }}>
          <div style={{ 
            display: 'flex', 
            gap: '1rem', 
            flexWrap: 'wrap',
            justifyContent: 'center'
          }}>
            <button
              onClick={() => setActiveTab('products')}
              className={`btn ${activeTab === 'products' ? 'btn-primary' : 'btn-secondary'}`}
              style={{ minWidth: '140px' }}
            >
              🛍️ Productos
            </button>
            <button
              onClick={() => setActiveTab('users')}
              className={`btn ${activeTab === 'users' ? 'btn-primary' : 'btn-secondary'}`}
              style={{ minWidth: '140px' }}
            >
              👥 Usuarios
            </button>
            <button
              onClick={() => setActiveTab('orders')}
              className={`btn ${activeTab === 'orders' ? 'btn-primary' : 'btn-secondary'}`}
              style={{ minWidth: '140px' }}
            >
              📦 Pedidos
            </button>
          </div>
        </div>

        {activeTab === 'products' && (
          <div>
            <div style={{ marginBottom: '2rem', textAlign: 'center' }}>
              <button
                onClick={() => {
                  setShowProductForm(!showProductForm);
                  setEditingProduct(null);
                  setProductForm({
                    nombre: '', descripcion: '', precio: '', stock: '', marca: '', categoria: 'lenceria', imagen: ''
                  });
                }}
                className="btn btn-primary sparkle"
                style={{ fontSize: '1.1rem', padding: '1rem 2rem' }}
              >
                {showProductForm ? '❌ Cancelar' : '✨ Agregar Producto Sensual'}
              </button>
            </div>

            {showProductForm && (
              <div className="card glow-effect" style={{ marginBottom: '2rem' }}>
                <h3 style={{
                  color: '#ff69b4',
                  fontSize: '1.8rem',
                  marginBottom: '1.5rem',
                  textAlign: 'center'
                }}>
                  {editingProduct ? '✏️ Editar Producto' : '🆕 Agregar Nuevo Producto Sensual'}
                </h3>
                <form onSubmit={handleProductSubmit}>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.5rem' }}>
                    <div className="form-group">
                      <label>💎 Nombre</label>
                      <input
                        type="text"
                        value={productForm.nombre}
                        onChange={(e) => setProductForm({...productForm, nombre: e.target.value})}
                        placeholder="Ej: Lencería Sensual Rosa"
                        required
                      />
                    </div>
                    <div className="form-group">
                      <label>🏷️ Marca</label>
                      <input
                        type="text"
                        value={productForm.marca}
                        onChange={(e) => setProductForm({...productForm, marca: e.target.value})}
                        placeholder="Ej: Victoria's Secret"
                        required
                      />
                    </div>
                    <div className="form-group">
                      <label>💰 Precio</label>
                      <input
                        type="number"
                        step="0.01"
                        value={productForm.precio}
                        onChange={(e) => setProductForm({...productForm, precio: e.target.value})}
                        placeholder="0.00"
                        required
                      />
                    </div>
                    <div className="form-group">
                      <label>📦 Stock</label>
                      <input
                        type="number"
                        value={productForm.stock}
                        onChange={(e) => setProductForm({...productForm, stock: e.target.value})}
                        placeholder="Cantidad disponible"
                        required
                      />
                    </div>
                    <div className="form-group">
                      <label>🎭 Categoría</label>
                      <select
                        value={productForm.categoria}
                        onChange={(e) => setProductForm({...productForm, categoria: e.target.value})}
                        required
                      >
                        <option value="lenceria">💋 Lencería</option>
                        <option value="juguetes">🎲 Juguetes</option>
                        <option value="aceites">🫙 Aceites & Lubricantes</option>
                        <option value="disfraces">🎭 Disfraces</option>
                        <option value="accesorios">💎 Accesorios</option>
                      </select>
                    </div>
                    <div className="form-group">
                      <label>🖼️ Imagen</label>
                      <input
                        type="text"
                        value={productForm.imagen}
                        onChange={(e) => setProductForm({...productForm, imagen: e.target.value})}
                        placeholder="lenceria-rosa.jpg"
                        required
                      />
                    </div>
                  </div>
                  <div className="form-group">
                    <label>📝 Descripción Sensual</label>
                    <textarea
                      value={productForm.descripcion}
                      onChange={(e) => setProductForm({...productForm, descripcion: e.target.value})}
                      rows="4"
                      placeholder="Describe este producto sensual y atractivo..."
                      required
                    />
                  </div>
                  <div style={{ textAlign: 'center', marginTop: '2rem' }}>
                    <button type="submit" className="btn btn-success" disabled={loading}>
                      {loading ? '⏳ Guardando...' : (editingProduct ? '💫 Actualizar' : '✨ Crear Producto')}
                    </button>
                  </div>
                </form>
              </div>
            )}

            {loading ? (
              <div style={{ textAlign: 'center', padding: '3rem' }}>
                <div className="loading" style={{ marginBottom: '1rem' }}></div>
                <p style={{ color: '#ff69b4', fontSize: '1.1rem' }}>Cargando productos sensuales...</p>
              </div>
            ) : (
              <div className="card">
                <h3 style={{ color: '#ff69b4', marginBottom: '1.5rem', textAlign: 'center' }}>
                  🛍️ Catálogo de Productos
                </h3>
                <div style={{ overflowX: 'auto' }}>
                  <table className="table">
                    <thead>
                      <tr>
                        <th>💎 Nombre</th>
                        <th>💰 Precio</th>
                        <th>📦 Stock</th>
                        <th>🎭 Categoría</th>
                        <th>⚙️ Acciones</th>
                      </tr>
                    </thead>
                    <tbody>
                      {products.map(product => (
                        <tr key={product.id_producto}>
                          <td style={{ fontWeight: '500' }}>{product.nombre}</td>
                          <td style={{ color: '#ff1493', fontWeight: 'bold' }}>${product.precio}</td>
                          <td>
                            <span className={`badge ${product.stock > 10 ? 'badge-success' : product.stock > 0 ? 'badge-warning' : 'badge-danger'}`}>
                              {product.stock}
                            </span>
                          </td>
                          <td>
                            <span className="badge badge-info">{product.categoria}</span>
                          </td>
                          <td>
                            <button
                              onClick={() => handleEditProduct(product)}
                              className="btn btn-primary"
                              style={{ marginRight: '0.5rem', padding: '0.4rem 1rem', fontSize: '0.9rem' }}
                            >
                              ✏️ Editar
                            </button>
                            <button
                              onClick={() => handleDeleteProduct(product.id_producto)}
                              className="btn btn-danger"
                              style={{ padding: '0.4rem 1rem', fontSize: '0.9rem' }}
                            >
                              🗑️ Eliminar
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
        )}

        {activeTab === 'users' && (
          <div className="card">
            <h3 style={{ color: '#ff69b4', marginBottom: '1.5rem', textAlign: 'center' }}>
              👥 Gestión de Usuarios VIP
            </h3>
            <div style={{
              background: 'rgba(255, 105, 180, 0.1)',
              border: '1px solid rgba(255, 105, 180, 0.3)',
              borderRadius: '15px',
              padding: '1.5rem',
              marginBottom: '2rem',
              fontSize: '1rem'
            }}>
              <strong style={{ color: '#ff69b4' }}>ℹ️ Información Importante:</strong>
              <p style={{ color: '#fff', marginTop: '0.5rem', marginBottom: 0 }}>
                Al eliminar un usuario, se eliminarán automáticamente todos sus productos creados y pedidos realizados.
              </p>
            </div>
            
            {loading ? (
              <div style={{ textAlign: 'center', padding: '3rem' }}>
                <div className="loading" style={{ marginBottom: '1rem' }}></div>
                <p style={{ color: '#ff69b4', fontSize: '1.1rem' }}>Cargando usuarios VIP...</p>
              </div>
            ) : (
              <div style={{ overflowX: 'auto' }}>
                <table className="table">
                  <thead>
                    <tr>
                      <th>👤 Nombre</th>
                      <th>📧 Email</th>
                      <th>🎭 Rol</th>
                      <th>🛍️ Productos</th>
                      <th>📦 Pedidos</th>
                      <th>⚙️ Acciones</th>
                    </tr>
                  </thead>
                  <tbody>
                    {users.map(userItem => {
                      const stats = userStats[userItem.id_usuario] || { products: 0, orders: 0 };
                      return (
                        <tr key={userItem.id_usuario}>
                          <td style={{ fontWeight: '500' }}>{userItem.nombre}</td>
                          <td style={{ color: '#ff69b4' }}>{userItem.email}</td>
                          <td>
                            <select
                              value={userItem.rol}
                              onChange={(e) => handleChangeUserRole(userItem.id_usuario, e.target.value)}
                              style={{
                                padding: '0.5rem',
                                border: '2px solid rgba(255, 20, 147, 0.3)',
                                borderRadius: '10px',
                                background: 'rgba(26, 10, 26, 0.6)',
                                color: '#fff',
                                fontSize: '0.9rem'
                              }}
                            >
                              <option value="usuario">👤 Usuario</option>
                              <option value="administrador">👑 Administrador</option>
                            </select>
                          </td>
                          <td>
                            <span className={`badge ${stats.products > 0 ? 'badge-warning' : 'badge-success'}`}>
                              {stats.products}
                            </span>
                          </td>
                          <td>
                            <span className={`badge ${stats.orders > 0 ? 'badge-warning' : 'badge-success'}`}>
                              {stats.orders}
                            </span>
                          </td>
                          <td>
                            <button
                              onClick={() => handleDeleteUser(userItem.id_usuario, userItem.nombre)}
                              className="btn btn-danger"
                              style={{ padding: '0.4rem 1rem', fontSize: '0.9rem' }}
                              disabled={userItem.id_usuario === user.id}
                              title={userItem.id_usuario === user.id ? 'No puedes eliminarte a ti mismo' : 'Eliminar usuario y todas sus dependencias'}
                            >
                              {userItem.id_usuario === user.id ? '👑 Tú' : '🗑️ Eliminar'}
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

        {activeTab === 'orders' && (
          <div className="card">
            <h3 style={{ color: '#ff69b4', marginBottom: '1.5rem', textAlign: 'center' }}>
              📦 Pedidos Sensuales
            </h3>
            {loading ? (
              <div style={{ textAlign: 'center', padding: '3rem' }}>
                <div className="loading" style={{ marginBottom: '1rem' }}></div>
                <p style={{ color: '#ff69b4', fontSize: '1.1rem' }}>Cargando pedidos...</p>
              </div>
            ) : (
              <div style={{ overflowX: 'auto' }}>
                <table className="table">
                  <thead>
                    <tr>
                      <th>🆔 ID</th>
                      <th>👤 Usuario</th>
                      <th>📅 Fecha</th>
                      <th>💰 Total</th>
                      <th>📊 Estado</th>
                      <th>🛍️ Productos</th>
                    </tr>
                  </thead>
                  <tbody>
                    {orders.map(order => (
                      <tr key={order.id_pedido}>
                        <td style={{ fontWeight: 'bold', color: '#ff1493' }}>#{order.id_pedido}</td>
                        <td>{order.usuario_nombre}</td>
                        <td>{new Date(order.fecha).toLocaleDateString()}</td>
                        <td style={{ color: '#ff1493', fontWeight: 'bold' }}>
                          ${parseFloat(order.total || 0).toFixed(2)}
                        </td>
                        <td>
                          <span className={`badge ${order.estado === 'pendiente' ? 'badge-warning' : 'badge-success'}`}>
                            {order.estado === 'pendiente' ? '⏳ Pendiente' : '✅ Completado'}
                          </span>
                        </td>
                        <td style={{ maxWidth: '200px', fontSize: '0.85rem', color: '#ff69b4' }}>
                          {order.productos || 'Sin productos'}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default Admin;