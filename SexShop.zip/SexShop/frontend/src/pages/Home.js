import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import ApiService from '../services/api';
import { showError } from '../utils/notifications';

const Home = () => {
  const [featuredProducts, setFeaturedProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const { addToCart } = useCart();

  // Cargar productos destacados al montar el componente
  useEffect(() => {
    loadFeaturedProducts();
  }, []);

  const loadFeaturedProducts = async () => {
    try {
      const response = await ApiService.getProducts();
      if (response.success) {
        // Tomar solo los primeros 6 productos como destacados
        setFeaturedProducts(response.products.slice(0, 6));
      }
    } catch (error) {
      showError('💔 Error al cargar productos sensuales', 'DATABASE_ERROR');
    } finally {
      setLoading(false);
    }
  };

  const handleAddToCart = (product) => {
    addToCart(product, 1);
  };

  const getProductsByCategory = (category) => {
    // Redirigir a la página de productos con filtro
    window.location.href = `/products?category=${category}`;
  };

  return (
    <div>
      {/* Hero Section Compacto - Lado Izquierdo */}
      <section style={{
        minHeight: '70vh',
        display: 'flex',
        alignItems: 'center',
        background: `linear-gradient(135deg, rgba(15, 15, 15, 0.9) 0%, rgba(26, 10, 26, 0.9) 25%, rgba(45, 27, 61, 0.9) 50%, rgba(26, 10, 26, 0.9) 75%, rgba(15, 15, 15, 0.9) 100%), 
                     url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 600"><defs><radialGradient id="grad1" cx="50%" cy="50%" r="50%"><stop offset="0%" style="stop-color:%23ff1493;stop-opacity:0.3" /><stop offset="50%" style="stop-color:%23ff69b4;stop-opacity:0.2" /><stop offset="100%" style="stop-color:%23da70d6;stop-opacity:0.1" /></radialGradient></defs><rect width="1200" height="600" fill="url(%23grad1)"/><circle cx="200" cy="150" r="4" fill="%23ff1493" opacity="0.4"><animate attributeName="opacity" values="0.4;0.8;0.4" dur="3s" repeatCount="indefinite"/></circle><circle cx="800" cy="300" r="3" fill="%23ff69b4" opacity="0.5"><animate attributeName="opacity" values="0.5;0.9;0.5" dur="2s" repeatCount="indefinite"/></circle><circle cx="1000" cy="100" r="5" fill="%23da70d6" opacity="0.3"><animate attributeName="opacity" values="0.3;0.7;0.3" dur="4s" repeatCount="indefinite"/></circle><circle cx="400" cy="450" r="2" fill="%23ff1493" opacity="0.6"><animate attributeName="opacity" values="0.6;1;0.6" dur="2.5s" repeatCount="indefinite"/></circle></svg>') center/cover`,
        position: 'relative',
        overflow: 'hidden'
      }}>
        <div className="container" style={{ display: 'flex', alignItems: 'center', gap: '4rem' }}>
          {/* Contenido Hero - Lado Izquierdo */}
          <div style={{ 
            flex: '1', 
            color: '#fff',
            zIndex: 2,
            textAlign: window.innerWidth <= 768 ? 'center' : 'left'
          }}>
            <div style={{
              fontSize: '1.2rem',
              marginBottom: '1rem',
              opacity: 0.9,
              animation: 'fadeInUp 1s ease-out'
            }}>
              💋✨
            </div>
            <h1 style={{
              fontSize: window.innerWidth <= 768 ? '2.5rem' : '4rem',
              marginBottom: '1rem',
              background: 'linear-gradient(45deg, #ff1493, #ff69b4, #da70d6, #ff1493)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              backgroundClip: 'text',
              textShadow: '0 0 30px rgba(255, 20, 147, 0.5)',
              animation: 'fadeInUp 1s ease-out',
              fontFamily: 'Georgia, serif',
              letterSpacing: '2px'
            }}>
              Oswal Shop
            </h1>
            <p style={{
              fontSize: '1.1rem',
              marginBottom: '2rem',
              opacity: 0.95,
              animation: 'fadeInUp 1s ease-out 0.3s both',
              lineHeight: '1.6'
            }}>
              💎 Descubre tu lado más sensual con nuestra colección exclusiva
            </p>
            <Link 
              to="/products" 
              className="sparkle"
              style={{
                display: 'inline-block',
                background: 'linear-gradient(45deg, #ff1493, #ff69b4, #da70d6)',
                color: '#fff',
                padding: '1rem 2.5rem',
                textDecoration: 'none',
                borderRadius: '50px',
                fontWeight: 'bold',
                fontSize: '1rem',
                transition: 'all 0.4s ease',
                boxShadow: '0 15px 40px rgba(255, 20, 147, 0.4)',
                animation: 'fadeInUp 1s ease-out 0.6s both',
                border: '2px solid transparent',
                backdropFilter: 'blur(10px)'
              }}
              onMouseOver={(e) => {
                e.target.style.transform = 'translateY(-5px) scale(1.05)';
                e.target.style.boxShadow = '0 20px 50px rgba(255, 20, 147, 0.6)';
                e.target.style.background = 'linear-gradient(45deg, #ff69b4, #da70d6, #ff1493)';
                e.target.style.borderColor = '#fff';
              }}
              onMouseOut={(e) => {
                e.target.style.transform = 'translateY(0) scale(1)';
                e.target.style.boxShadow = '0 15px 40px rgba(255, 20, 147, 0.4)';
                e.target.style.background = 'linear-gradient(45deg, #ff1493, #ff69b4, #da70d6)';
                e.target.style.borderColor = 'transparent';
              }}
            >
              ✨ Explorar Productos
            </Link>
          </div>

          {/* Preview de Categorías - Lado Derecho */}
          {window.innerWidth > 768 && (
            <div style={{ 
              flex: '1',
              display: 'grid',
              gridTemplateColumns: '1fr 1fr',
              gap: '1rem',
              zIndex: 2
            }}>
              {/* Mini Card Lencería */}
              <div className="card glow-effect" style={{
                padding: '1.5rem',
                textAlign: 'center',
                minHeight: '200px',
                cursor: 'pointer',
                transition: 'all 0.3s ease'
              }}
              onClick={() => getProductsByCategory('lenceria')}
              onMouseOver={(e) => {
                e.currentTarget.style.transform = 'translateY(-10px) scale(1.05)';
              }}
              onMouseOut={(e) => {
                e.currentTarget.style.transform = 'translateY(0) scale(1)';
              }}>
                <div style={{
                  fontSize: '3rem',
                  marginBottom: '1rem',
                  color: '#ff69b4'
                }}>💋</div>
                <h4 style={{ color: '#ff69b4', marginBottom: '0.5rem' }}>Lencería</h4>
                <p style={{ color: '#fff', fontSize: '0.9rem', opacity: 0.8 }}>Seducción pura</p>
              </div>

              {/* Mini Card Juguetes */}
              <div className="card glow-effect" style={{
                padding: '1.5rem',
                textAlign: 'center',
                minHeight: '200px',
                cursor: 'pointer',
                transition: 'all 0.3s ease'
              }}
              onClick={() => getProductsByCategory('juguetes')}
              onMouseOver={(e) => {
                e.currentTarget.style.transform = 'translateY(-10px) scale(1.05)';
              }}
              onMouseOut={(e) => {
                e.currentTarget.style.transform = 'translateY(0) scale(1)';
              }}>
                <div style={{
                  fontSize: '3rem',
                  marginBottom: '1rem',
                  color: '#8a2be2'
                }}>🎲</div>
                <h4 style={{ color: '#8a2be2', marginBottom: '0.5rem' }}>Juguetes</h4>
                <p style={{ color: '#fff', fontSize: '0.9rem', opacity: 0.8 }}>Placer infinito</p>
              </div>

              {/* Mini Card Aceites - Span 2 columns */}
              <div className="card glow-effect" style={{
                padding: '1.5rem',
                textAlign: 'center',
                minHeight: '140px',
                gridColumn: 'span 2',
                cursor: 'pointer',
                transition: 'all 0.3s ease'
              }}
              onClick={() => getProductsByCategory('aceites')}
              onMouseOver={(e) => {
                e.currentTarget.style.transform = 'translateY(-10px) scale(1.02)';
              }}
              onMouseOut={(e) => {
                e.currentTarget.style.transform = 'translateY(0) scale(1)';
              }}>
                <div style={{
                  fontSize: '2.5rem',
                  marginBottom: '0.5rem',
                  color: '#da70d6'
                }}>🫙</div>
                <h4 style={{ color: '#da70d6', marginBottom: '0.5rem' }}>Aceites & Lubricantes</h4>
                <p style={{ color: '#fff', fontSize: '0.9rem', opacity: 0.8 }}>Experiencias sensuales</p>
              </div>
            </div>
          )}
        </div>

        {/* Partículas de fondo animadas */}
        <div style={{
          position: 'absolute',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          zIndex: 1,
          pointerEvents: 'none'
        }}>
          {[...Array(15)].map((_, i) => (
            <div
              key={i}
              style={{
                position: 'absolute',
                width: Math.random() * 4 + 2 + 'px',
                height: Math.random() * 4 + 2 + 'px',
                background: ['#ff1493', '#ff69b4', '#da70d6'][Math.floor(Math.random() * 3)],
                borderRadius: '50%',
                left: Math.random() * 100 + '%',
                top: Math.random() * 100 + '%',
                animation: `sparkle ${Math.random() * 3 + 2}s ease-in-out infinite`,
                opacity: Math.random() * 0.8 + 0.2
              }}
            />
          ))}
        </div>
      </section>

      {/* Featured Products Section - Productos en Zigzag */}
      <section className="section section-alt">
        <div className="container">
          <div style={{ textAlign: 'center', marginBottom: '4rem' }}>
            <h2 className="section-title white sparkle">✨ Productos Más Deseados</h2>
            <p style={{ 
              color: '#ff69b4', 
              fontSize: '1.2rem', 
              marginTop: '1rem',
              opacity: 0.9 
            }}>
              💎 Nuestra selección premium que enamora
            </p>
          </div>
          
          {loading ? (
            <div style={{ textAlign: 'center', padding: '4rem' }}>
              <div className="loading" style={{ marginBottom: '1.5rem' }}></div>
              <p style={{ 
                color: '#ff69b4', 
                marginTop: '1rem', 
                fontSize: '1.2rem',
                animation: 'pulse 2s infinite'
              }}>
                💖 Cargando productos sensuales...
              </p>
            </div>
          ) : (
            <div>
              {/* Productos en layout asimétrico */}
              {featuredProducts.map((product, index) => (
                <div 
                  key={product.id_producto} 
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '3rem',
                    marginBottom: '4rem',
                    flexDirection: window.innerWidth <= 768 ? 'column' : 
                                  (index % 2 === 0 ? 'row' : 'row-reverse'),
                    textAlign: window.innerWidth <= 768 ? 'center' : 
                              (index % 2 === 0 ? 'left' : 'right')
                  }}
                >
                  {/* Imagen del producto */}
                  <div style={{ 
                    flex: '1',
                    maxWidth: window.innerWidth <= 768 ? '100%' : '400px'
                  }}>
                    <div className="card glow-effect" style={{
                      padding: '2rem',
                      background: `linear-gradient(45deg, 
                        ${index % 3 === 0 ? 'rgba(255, 20, 147, 0.1)' : 
                          index % 3 === 1 ? 'rgba(138, 43, 226, 0.1)' : 
                          'rgba(218, 112, 214, 0.1)'}, 
                        ${index % 3 === 0 ? 'rgba(255, 105, 180, 0.1)' : 
                          index % 3 === 1 ? 'rgba(153, 50, 204, 0.1)' : 
                          'rgba(255, 20, 147, 0.1)'})`,
                      border: `2px solid ${index % 3 === 0 ? 'rgba(255, 20, 147, 0.3)' : 
                                           index % 3 === 1 ? 'rgba(138, 43, 226, 0.3)' : 
                                           'rgba(218, 112, 214, 0.3)'}`,
                      borderRadius: '20px',
                      aspectRatio: '1',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      position: 'relative',
                      overflow: 'hidden'
                    }}>
                      <img 
                        src={`/images/${product.imagen}`} 
                        alt={product.nombre}
                        style={{ 
                          width: '250px', 
                          height: '250px', 
                          objectFit: 'cover',
                          borderRadius: '15px',
                          filter: `drop-shadow(0 10px 25px ${index % 3 === 0 ? 'rgba(255, 20, 147, 0.4)' : 
                                                            index % 3 === 1 ? 'rgba(138, 43, 226, 0.4)' : 
                                                            'rgba(218, 112, 214, 0.4)'})`
                        }}
                        onError={(e) => { 
                          e.target.style.display = 'none'; 
                          e.target.nextSibling.style.display = 'flex'; 
                        }}
                      />
                      <div style={{ 
                        display: 'none',
                        alignItems: 'center',
                        justifyContent: 'center',
                        width: '100%',
                        height: '100%',
                        fontSize: '5rem',
                        color: index % 3 === 0 ? '#ff1493' : 
                               index % 3 === 1 ? '#8a2be2' : '#da70d6'
                      }}>💎</div>
                    </div>
                  </div>

                  {/* Información del producto */}
                  <div style={{ 
                    flex: '1',
                    padding: window.innerWidth <= 768 ? '0' : '2rem'
                  }}>
                    <div style={{
                      fontSize: '1.5rem',
                      marginBottom: '1rem',
                      opacity: 0.7
                    }}>
                      {index % 3 === 0 ? '💋' : index % 3 === 1 ? '🎲' : '🫙'}
                    </div>
                    
                    <h3 style={{ 
                      fontSize: window.innerWidth <= 768 ? '1.8rem' : '2.2rem',
                      marginBottom: '1rem', 
                      color: index % 3 === 0 ? '#ff69b4' : 
                             index % 3 === 1 ? '#8a2be2' : '#da70d6',
                      fontFamily: 'Georgia, serif',
                      lineHeight: '1.2'
                    }}>
                      {product.nombre}
                    </h3>
                    
                    <p style={{ 
                      color: '#fff', 
                      marginBottom: '2rem', 
                      fontSize: '1.1rem',
                      lineHeight: '1.6',
                      opacity: 0.9,
                      maxWidth: '500px'
                    }}>
                      {product.descripcion}
                    </p>
                    
                    <div style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '2rem',
                      flexWrap: 'wrap',
                      justifyContent: window.innerWidth <= 768 ? 'center' : 
                                     (index % 2 === 0 ? 'flex-start' : 'flex-end')
                    }}>
                      <div style={{
                        fontSize: '2rem',
                        fontWeight: 'bold',
                        background: `linear-gradient(45deg, 
                          ${index % 3 === 0 ? '#ff1493, #ff69b4' : 
                            index % 3 === 1 ? '#8a2be2, #9932cc' : 
                            '#da70d6, #ff1493'})`,
                        WebkitBackgroundClip: 'text',
                        WebkitTextFillColor: 'transparent'
                      }}>
                        💰 ${product.precio}
                      </div>
                      
                      <button 
                        className={`btn ${product.stock > 0 ? 
                          (index % 3 === 0 ? 'btn-primary' : 
                           index % 3 === 1 ? 'btn-success' : 'btn-primary') + ' sparkle' 
                          : 'btn-secondary'}`}
                        style={{ 
                          fontSize: '1.1rem',
                          padding: '1rem 2rem',
                          minWidth: '200px'
                        }}
                        onClick={() => handleAddToCart(product)}
                        disabled={product.stock <= 0}
                      >
                        {product.stock > 0 ? '💖 Agregar al Carrito' : '💔 Sin Stock'}
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Categories Section Mobile - Solo visible en móvil */}
      {window.innerWidth <= 768 && (
        <section className="section section-white">
          <div className="container">
            <h2 className="section-title sparkle">💎 Nuestras Categorías</h2>
            <div style={{
              display: 'grid',
              gap: '2rem',
              marginTop: '3rem'
            }}>
              {/* Lencería */}
              <div className="card glow-effect" style={{
                textAlign: 'center',
                padding: '2rem'
              }}>
                <div style={{
                  fontSize: '4rem',
                  marginBottom: '1rem',
                  color: '#ff69b4'
                }}>💋</div>
                <h3 style={{ 
                  fontSize: '1.5rem', 
                  marginBottom: '1rem', 
                  color: '#ff69b4',
                  fontFamily: 'Georgia, serif'
                }}>
                  Lencería Sensual
                </h3>
                <p style={{ 
                  color: '#fff', 
                  marginBottom: '2rem',
                  fontSize: '1rem',
                  lineHeight: '1.6',
                  opacity: 0.9
                }}>
                  Conjuntos seductores y elegantes que realzan tu belleza natural.
                </p>
                <button 
                  className="btn btn-primary sparkle"
                  onClick={() => getProductsByCategory('lenceria')}
                  style={{ width: '100%' }}
                >
                  🛍️ Ver Colección
                </button>
              </div>

              {/* Juguetes */}
              <div className="card glow-effect" style={{
                textAlign: 'center',
                padding: '2rem'
              }}>
                <div style={{
                  fontSize: '4rem',
                  marginBottom: '1rem',
                  color: '#8a2be2'
                }}>🎲</div>
                <h3 style={{ 
                  fontSize: '1.5rem', 
                  marginBottom: '1rem', 
                  color: '#8a2be2',
                  fontFamily: 'Georgia, serif'
                }}>
                  Juguetes Íntimos
                </h3>
                <p style={{ 
                  color: '#fff', 
                  marginBottom: '2rem',
                  fontSize: '1rem',
                  lineHeight: '1.6',
                  opacity: 0.9
                }}>
                  Juguetes premium diseñados para el máximo placer y satisfacción.
                </p>
                <button 
                  className="btn btn-success sparkle"
                  onClick={() => getProductsByCategory('juguetes')}
                  style={{ width: '100%' }}
                >
                  ✨ Descubrir Más
                </button>
              </div>

              {/* Aceites */}
              <div className="card glow-effect" style={{
                textAlign: 'center',
                padding: '2rem'
              }}>
                <div style={{
                  fontSize: '4rem',
                  marginBottom: '1rem',
                  color: '#da70d6'
                }}>🫙</div>
                <h3 style={{ 
                  fontSize: '1.5rem', 
                  marginBottom: '1rem', 
                  color: '#da70d6',
                  fontFamily: 'Georgia, serif'
                }}>
                  Aceites & Lubricantes
                </h3>
                <p style={{ 
                  color: '#fff', 
                  marginBottom: '2rem',
                  fontSize: '1rem',
                  lineHeight: '1.6',
                  opacity: 0.9
                }}>
                  Productos íntimos para experiencias sensuales incomparables.
                </p>
                <button 
                  className="btn btn-primary sparkle"
                  onClick={() => getProductsByCategory('aceites')}
                  style={{ width: '100%' }}
                >
                  💫 Explorar Aromas
                </button>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* Call to Action Final */}
      <section style={{
        background: 'linear-gradient(45deg, rgba(255, 20, 147, 0.1), rgba(138, 43, 226, 0.1))',
        padding: '4rem 0',
        textAlign: 'center',
        borderTop: '2px solid rgba(255, 20, 147, 0.3)'
      }}>
        <div className="container">
          <h2 style={{
            fontSize: '2.5rem',
            color: '#ff69b4',
            marginBottom: '1rem',
            fontFamily: 'Georgia, serif'
          }}>
            ✨ ¿Listo para una experiencia única?
          </h2>
          <p style={{
            color: '#fff',
            fontSize: '1.2rem',
            marginBottom: '2rem',
            opacity: 0.9
          }}>
            💎 Explora toda nuestra colección y descubre tu lado más sensual
          </p>
          <Link 
            to="/products" 
            className="btn btn-primary sparkle"
            style={{
              fontSize: '1.2rem',
              padding: '1.2rem 3rem'
            }}
          >
            🛍️ Ver Todos los Productos
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Home;