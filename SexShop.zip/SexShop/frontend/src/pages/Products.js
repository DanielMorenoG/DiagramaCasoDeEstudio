import React, { useState, useEffect } from 'react';
import { useCart } from '../context/CartContext';
import ApiService from '../services/api';
import { showError } from '../utils/notifications';

const Products = () => {
  const [products, setProducts] = useState([]);
  const [filteredProducts, setFilteredProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [viewMode, setViewMode] = useState('grid'); // grid or list
  const { addToCart } = useCart();

  const categories = [
    { value: 'all', label: '💎 Todos', icon: '🔥', color: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)' },
    { value: 'lenceria', label: '👙 Lencería'},
    { value: 'lubricantes', label: '💧 Lubricantes',},
    { value: 'juguetes', label: '🎯 Juguetes',}
  ];

  useEffect(() => {
    loadProducts();
  }, []);

  useEffect(() => {
    filterProducts();
  }, [products, selectedCategory, searchTerm]);

  const loadProducts = async () => {
    try {
      const response = await ApiService.getProducts();
      if (response.success) {
        setProducts(response.products);
      }
    } catch (error) {
      showError('Error al cargar productos', 'DATABASE_ERROR');
    } finally {
      setLoading(false);
    }
  };

  const filterProducts = () => {
    let filtered = products;

    if (selectedCategory !== 'all') {
      filtered = filtered.filter(product => product.categoria === selectedCategory);
    }

    if (searchTerm) {
      filtered = filtered.filter(product =>
        product.nombre.toLowerCase().includes(searchTerm.toLowerCase()) ||
        product.descripcion.toLowerCase().includes(searchTerm.toLowerCase()) ||
        product.marca.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    setFilteredProducts(filtered);
  };

  const handleAddToCart = (product) => {
    addToCart(product, 1);
  };

  const getCategoryData = (category) => {
    return categories.find(cat => cat.value === category) || categories[0];
  };

  if (loading) {
    return (
      <div style={{
        minHeight: '100vh',
        background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        flexDirection: 'column'
      }}>
        <div style={{
          width: '80px',
          height: '80px',
          border: '4px solid rgba(255,255,255,0.3)',
          borderTop: '4px solid #fff',
          borderRadius: '50%',
          animation: 'spin 1s linear infinite'
        }}></div>
        <p style={{ color: 'white', marginTop: '1rem', fontSize: '1.2rem' }}>
          Cargando productos sensuales...
        </p>
        <style>{`
          @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
          }
        `}</style>
      </div>
    );
  }

  return (
    <div style={{
      minHeight: '100vh',
      background: 'linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%)',
      paddingTop: '2rem'
    }}>
      {/* Header Hero */}
      <div style={{
        textAlign: 'center',
        padding: '3rem 1rem',
        background: 'linear-gradient(135deg, rgba(255,255,255,0.1) 0%, rgba(255,255,255,0.05) 100%)',
        margin: '0 2rem 3rem',
        borderRadius: '25px',
        backdropFilter: 'blur(10px)',
        border: '1px solid rgba(255,255,255,0.1)'
      }}>
        <h1 style={{
          fontSize: 'clamp(2.5rem, 5vw, 4rem)',
          background: 'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)',
          WebkitBackgroundClip: 'text',
          WebkitTextFillColor: 'transparent',
          fontWeight: 'bold',
          marginBottom: '1rem',
          textShadow: '0 4px 20px rgba(245, 87, 108, 0.3)'
        }}>
          💋 Colección Íntima
        </h1>
        <p style={{
          color: 'rgba(255,255,255,0.8)',
          fontSize: '1.2rem',
          maxWidth: '600px',
          margin: '0 auto'
        }}>
          Descubre nuestra exclusiva selección de productos para el placer y la intimidad
        </p>
      </div>

      <div style={{ maxWidth: '1400px', margin: '0 auto', padding: '0 2rem' }}>
        
        {/* Filtros Modernos */}
        <div style={{
          background: 'rgba(255,255,255,0.95)',
          borderRadius: '20px',
          padding: '2rem',
          marginBottom: '3rem',
          boxShadow: '0 20px 60px rgba(0,0,0,0.3)',
          border: '1px solid rgba(255,255,255,0.2)',
          backdropFilter: 'blur(20px)'
        }}>
          {/* Búsqueda Principal */}
          <div style={{
            position: 'relative',
            marginBottom: '2rem'
          }}>
            <input
              type="text"
              placeholder="🔍 Busca tu producto ideal..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              style={{
                width: '100%',
                padding: '1rem 3rem 1rem 1.5rem',
                fontSize: '1.1rem',
                border: '2px solid transparent',
                borderRadius: '50px',
                background: 'linear-gradient(white, white) padding-box, linear-gradient(135deg, #f093fb, #f5576c) border-box',
                outline: 'none',
                transition: 'all 0.3s ease'
              }}
            />
            <div style={{
              position: 'absolute',
              right: '1.5rem',
              top: '50%',
              transform: 'translateY(-50%)',
              fontSize: '1.2rem',
              color: '#f5576c'
            }}>
              🔍
            </div>
          </div>

          {/* Categorías como Pills */}
          <div style={{
            display: 'flex',
            flexWrap: 'wrap',
            gap: '1rem',
            marginBottom: '1.5rem',
            justifyContent: 'center'
          }}>
            {categories.map(category => (
              <button
                key={category.value}
                onClick={() => setSelectedCategory(category.value)}
                style={{
                  padding: '0.8rem 1.5rem',
                  border: 'none',
                  borderRadius: '25px',
                  background: selectedCategory === category.value 
                    ? category.color 
                    : 'rgba(255,255,255,0.8)',
                  color: selectedCategory === category.value ? 'white' : '#333',
                  fontSize: '1rem',
                  fontWeight: 'bold',
                  cursor: 'pointer',
                  transition: 'all 0.3s ease',
                  boxShadow: selectedCategory === category.value 
                    ? '0 8px 25px rgba(245, 87, 108, 0.4)' 
                    : '0 4px 15px rgba(0,0,0,0.1)',
                  transform: selectedCategory === category.value ? 'translateY(-2px)' : 'none',
                  minWidth: 'fit-content'
                }}
              >
                <span style={{ marginRight: '0.5rem' }}>{category.icon}</span>
                {category.label}
              </button>
            ))}
          </div>

          {/* Controles */}
          <div style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            flexWrap: 'wrap',
            gap: '1rem'
          }}>
            <div style={{ color: '#666', fontSize: '1rem' }}>
              ✨ {filteredProducts.length} productos encontrados de {products.length}
            </div>
            
            <div style={{ display: 'flex', gap: '1rem', alignItems: 'center' }}>
              <button
                onClick={() => {
                  setSearchTerm('');
                  setSelectedCategory('all');
                }}
                style={{
                  padding: '0.5rem 1rem',
                  background: 'linear-gradient(135deg, #667eea, #764ba2)',
                  color: 'white',
                  border: 'none',
                  borderRadius: '20px',
                  cursor: 'pointer',
                  fontSize: '0.9rem'
                }}
              >
                🗑️ Limpiar
              </button>
              
              <div style={{ display: 'flex', background: '#f0f0f0', borderRadius: '20px', padding: '0.3rem' }}>
                <button
                  onClick={() => setViewMode('grid')}
                  style={{
                    padding: '0.5rem 1rem',
                    background: viewMode === 'grid' ? '#f5576c' : 'transparent',
                    color: viewMode === 'grid' ? 'white' : '#666',
                    border: 'none',
                    borderRadius: '15px',
                    cursor: 'pointer'
                  }}
                >
                  📱
                </button>
                <button
                  onClick={() => setViewMode('list')}
                  style={{
                    padding: '0.5rem 1rem',
                    background: viewMode === 'list' ? '#f5576c' : 'transparent',
                    color: viewMode === 'list' ? 'white' : '#666',
                    border: 'none',
                    borderRadius: '15px',
                    cursor: 'pointer'
                  }}
                >
                  📋
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Productos */}
        {filteredProducts.length === 0 ? (
          <div style={{
            textAlign: 'center',
            color: 'white',
            padding: '4rem 2rem',
            background: 'rgba(255,255,255,0.1)',
            borderRadius: '20px',
            backdropFilter: 'blur(10px)'
          }}>
            <div style={{ fontSize: '4rem', marginBottom: '1rem' }}>😔</div>
            <h3 style={{ marginBottom: '1rem' }}>No encontramos productos</h3>
            <p>Intenta cambiar los filtros o buscar algo diferente</p>
          </div>
        ) : (
          <div style={{
            display: 'grid',
            gridTemplateColumns: viewMode === 'grid' 
              ? 'repeat(auto-fit, minmax(350px, 1fr))' 
              : '1fr',
            gap: '2rem',
            marginBottom: '3rem'
          }}>
            {filteredProducts.map(product => {
              const categoryData = getCategoryData(product.categoria);
              
              return (
                <div 
                  key={product.id_producto} 
                  style={{
                    background: 'rgba(255,255,255,0.95)',
                    borderRadius: '20px',
                    overflow: 'hidden',
                    boxShadow: '0 15px 40px rgba(0,0,0,0.2)',
                    transition: 'all 0.3s ease',
                    border: '1px solid rgba(255,255,255,0.2)',
                    display: viewMode === 'list' ? 'flex' : 'block',
                    alignItems: viewMode === 'list' ? 'center' : 'normal'
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.transform = 'translateY(-10px)';
                    e.currentTarget.style.boxShadow = '0 25px 60px rgba(245, 87, 108, 0.3)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.transform = 'translateY(0)';
                    e.currentTarget.style.boxShadow = '0 15px 40px rgba(0,0,0,0.2)';
                  }}
                >
                  {/* Imagen del Producto */}
                  <div style={{
                    height: viewMode === 'list' ? '200px' : '300px',
                    width: viewMode === 'list' ? '200px' : '100%',
                    flexShrink: 0,
                    background: 'linear-gradient(135deg, #2b0346ff 0%, #e9ecef 100%)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    position: 'relative',
                    overflow: 'hidden'
                  }}>
                    <img 
                      src={`/images/${product.imagen}`} 
                      alt={product.nombre}
                      style={{ 
                        width: '80%', 
                        height: '80%', 
                        objectFit: 'contain',
                        transition: 'all 0.3s ease'
                      }}
                      onError={(e) => { 
                        e.target.style.display = 'none'; 
                        e.target.nextSibling.style.display = 'flex'; 
                      }}
                      onMouseEnter={(e) => {
                        e.target.style.transform = 'scale(1.1)';
                      }}
                      onMouseLeave={(e) => {
                        e.target.style.transform = 'scale(1)';
                      }}
                    />
                    <div style={{ 
                      display: 'none',
                      alignItems: 'center',
                      justifyContent: 'center',
                      fontSize: '4rem',
                      color: '#f5576c'
                    }}>
                      {categoryData.icon}
                    </div>
                    
                    {/* Badges */}
                    <div style={{
                      position: 'absolute',
                      top: '15px',
                      right: '15px',
                      background: categoryData.color,
                      color: 'white',
                      padding: '0.5rem 1rem',
                      borderRadius: '20px',
                      fontSize: '0.8rem',
                      fontWeight: 'bold',
                      boxShadow: '0 4px 15px rgba(0,0,0,0.2)'
                    }}>
                      {categoryData.icon} {product.categoria}
                    </div>

                    {product.stock <= 5 && (
                      <div style={{
                        position: 'absolute',
                        top: '15px',
                        left: '15px',
                        background: product.stock === 0 
                          ? 'linear-gradient(135deg, #ff416c, #ff4b2b)' 
                          : 'linear-gradient(135deg, #ffa726, #ff7043)',
                        color: 'white',
                        padding: '0.5rem 1rem',
                        borderRadius: '20px',
                        fontSize: '0.8rem',
                        fontWeight: 'bold',
                        boxShadow: '0 4px 15px rgba(0,0,0,0.2)',
                        animation: product.stock <= 2 ? 'pulse 2s infinite' : 'none'
                      }}>
                      {product.stock === 0 ? '❌ Sin Stock' : `⚡ Solo ${product.stock}`}
                      </div>
                    )}
                  </div>

                  {/* Información del Producto */}
                  <div style={{ 
                    padding: '1.5rem',
                    flex: viewMode === 'list' ? 1 : 'none'
                  }}>
                    <h3 style={{ 
                      fontSize: '1.4rem', 
                      marginBottom: '0.8rem', 
                      color: '#2c3e50',
                      fontWeight: 'bold',
                      lineHeight: '1.3'
                    }}>
                      {product.nombre}
                    </h3>
                    
                    <p style={{ 
                      color: '#7f8c8d', 
                      marginBottom: '1rem', 
                      fontSize: '1rem',
                      lineHeight: '1.5',
                      opacity: '0.8'
                    }}>
                      {product.descripcion}
                    </p>

                    <div style={{ 
                      display: 'flex', 
                      justifyContent: 'space-between', 
                      alignItems: 'center',
                      marginBottom: '1.5rem',
                      padding: '1rem',
                      background: 'rgba(245, 87, 108, 0.1)',
                      borderRadius: '15px',
                      fontSize: '0.9rem'
                    }}>
                      <div style={{ display: 'flex', flexDirection: 'column', gap: '0.3rem' }}>
                        <span style={{ color: '#666' }}>
                          <strong>🏷️ Marca:</strong> {product.marca}
                        </span>
                        <span style={{ color: '#666' }}>
                          <strong>📦 Stock:</strong> {product.stock} unidades
                        </span>
                      </div>
                    </div>

                    <div style={{
                      display: 'flex',
                      justifyContent: 'space-between',
                      alignItems: 'center',
                      gap: '1rem'
                    }}>
                      <div style={{
                        fontSize: '2rem',
                        fontWeight: 'bold',
                        background: 'linear-gradient(135deg, #f093fb, #f5576c)',
                        WebkitBackgroundClip: 'text',
                        WebkitTextFillColor: 'transparent'
                      }}>
                        ${parseFloat(product.precio).toFixed(2)}
                      </div>

                      <button 
                        onClick={() => handleAddToCart(product)}
                        disabled={product.stock <= 0}
                        style={{
                          padding: '1rem 2rem',
                          border: 'none',
                          borderRadius: '25px',
                          background: product.stock > 0 
                            ? 'linear-gradient(135deg, #f093fb, #f5576c)' 
                            : 'linear-gradient(135deg, #bdc3c7, #95a5a6)',
                          color: 'white',
                          fontSize: '1rem',
                          fontWeight: 'bold',
                          cursor: product.stock > 0 ? 'pointer' : 'not-allowed',
                          transition: 'all 0.3s ease',
                          boxShadow: product.stock > 0 
                            ? '0 8px 25px rgba(245, 87, 108, 0.4)' 
                            : '0 4px 15px rgba(0,0,0,0.2)',
                          minWidth: '150px'
                        }}
                        onMouseEnter={(e) => {
                          if (product.stock > 0) {
                            e.target.style.transform = 'translateY(-2px)';
                            e.target.style.boxShadow = '0 12px 35px rgba(245, 87, 108, 0.6)';
                          }
                        }}
                        onMouseLeave={(e) => {
                          if (product.stock > 0) {
                            e.target.style.transform = 'translateY(0)';
                            e.target.style.boxShadow = '0 8px 25px rgba(245, 87, 108, 0.4)';
                          }
                        }}
                      >
                        {product.stock > 0 ? '🛒 Agregar' : '❌ Sin Stock'}
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      <style>{`
        @keyframes pulse {
          0%, 100% { transform: scale(1); }
          50% { transform: scale(1.05); }
        }
        
        @media (max-width: 768px) {
          .grid {
            grid-template-columns: 1fr !important;
          }
        }
      `}</style>
    </div>
  );
};

export default Products;