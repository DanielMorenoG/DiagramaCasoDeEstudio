import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const Login = () => {
  const [formData, setFormData] = useState({
    email: '',
    password: ''
  });
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleInputChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    const result = await login(formData.email, formData.password);
    
    if (result.success) {
      // Redirigir según el rol del usuario
      if (result.user.role === 'administrador') {
        navigate('/admin');
      } else {
        navigate('/');
      }
    }
    
    setLoading(false);
  };

  return (
    <div style={{
      minHeight: '100vh',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: `linear-gradient(135deg, rgba(15, 15, 15, 0.95) 0%, rgba(26, 10, 26, 0.95) 25%, rgba(45, 27, 61, 0.95) 50%, rgba(26, 10, 26, 0.95) 75%, rgba(15, 15, 15, 0.95) 100%), 
                   url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 600"><defs><radialGradient id="grad1" cx="50%" cy="50%" r="50%"><stop offset="0%" style="stop-color:%23ff1493;stop-opacity:0.2" /><stop offset="50%" style="stop-color:%23ff69b4;stop-opacity:0.1" /><stop offset="100%" style="stop-color:%23da70d6;stop-opacity:0.05" /></radialGradient></defs><rect width="1200" height="600" fill="url(%23grad1)"/><circle cx="200" cy="150" r="3" fill="%23ff1493" opacity="0.3"><animate attributeName="opacity" values="0.3;0.7;0.3" dur="4s" repeatCount="indefinite"/></circle><circle cx="800" cy="300" r="2" fill="%23ff69b4" opacity="0.4"><animate attributeName="opacity" values="0.4;0.8;0.4" dur="3s" repeatCount="indefinite"/></circle><circle cx="1000" cy="100" r="4" fill="%23da70d6" opacity="0.2"><animate attributeName="opacity" values="0.2;0.6;0.2" dur="5s" repeatCount="indefinite"/></circle></svg>') center/cover`,
      padding: '2rem',
      position: 'relative',
      overflow: 'hidden'
    }}>
      
      {/* Partículas de fondo */}
      <div style={{
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        zIndex: 1,
        pointerEvents: 'none'
      }}>
        {[...Array(12)].map((_, i) => (
          <div
            key={i}
            style={{
              position: 'absolute',
              width: Math.random() * 3 + 1 + 'px',
              height: Math.random() * 3 + 1 + 'px',
              background: ['#ff1493', '#ff69b4', '#da70d6'][Math.floor(Math.random() * 3)],
              borderRadius: '50%',
              left: Math.random() * 100 + '%',
              top: Math.random() * 100 + '%',
              animation: `sparkle ${Math.random() * 4 + 3}s ease-in-out infinite`,
              opacity: Math.random() * 0.6 + 0.2
            }}
          />
        ))}
      </div>

      {/* Contenedor principal con layout dividido */}
      <div style={{
        display: 'flex',
        maxWidth: '1000px',
        width: '100%',
        backgroundColor: 'rgba(20, 20, 20, 0.95)',
        borderRadius: '20px',
        boxShadow: '0 25px 60px rgba(0, 0, 0, 0.6), 0 0 50px rgba(255, 20, 147, 0.2)',
        overflow: 'hidden',
        backdropFilter: 'blur(20px)',
        border: '1px solid rgba(255, 20, 147, 0.3)',
        zIndex: 2,
        position: 'relative',
        flexDirection: window.innerWidth <= 768 ? 'column' : 'row',
        minHeight: window.innerWidth <= 768 ? 'auto' : '600px'
      }}>
        
        {/* Panel izquierdo - Branding */}
        <div style={{
          flex: '1',
          background: `linear-gradient(135deg, rgba(255, 20, 147, 0.2), rgba(138, 43, 226, 0.2), rgba(218, 112, 214, 0.2)), 
                       url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 600"><defs><radialGradient id="brandGrad" cx="50%" cy="50%" r="70%"><stop offset="0%" style="stop-color:%23ff1493;stop-opacity:0.4" /><stop offset="100%" style="stop-color:%23da70d6;stop-opacity:0.1" /></radialGradient></defs><rect width="400" height="600" fill="url(%23brandGrad)"/></svg>')`,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          padding: '3rem 2rem',
          textAlign: 'center',
          position: 'relative',
          minHeight: window.innerWidth <= 768 ? '200px' : 'auto'
        }}>
          
          {/* Logo/Icono principal */}
          <div style={{
            fontSize: '4rem',
            marginBottom: '2rem',
            animation: 'pulse 3s infinite',
            filter: 'drop-shadow(0 5px 15px rgba(255, 20, 147, 0.5))'
          }}>
            💋✨
          </div>

          {/* Título de marca */}
          <h1 style={{
            fontSize: window.innerWidth <= 768 ? '2.5rem' : '3.5rem',
            marginBottom: '1rem',
            background: 'linear-gradient(45deg, #ff1493, #ff69b4, #da70d6, #ff1493)',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            backgroundClip: 'text',
            fontFamily: 'Georgia, serif',
            letterSpacing: '2px',
            textShadow: '0 0 30px rgba(255, 20, 147, 0.3)',
            animation: 'fadeInUp 1s ease-out'
          }}>
            SexShop
          </h1>

          {/* Subtítulo */}
          <p style={{
            color: '#fff',
            fontSize: '1.1rem',
            opacity: 0.9,
            lineHeight: '1.6',
            maxWidth: '300px',
            animation: 'fadeInUp 1s ease-out 0.3s both'
          }}>
            💎 Bienvenido de vuelta a tu espacio de deseo y seducción
          </p>

          {/* Decoración */}
          <div style={{
            marginTop: '2rem',
            display: 'flex',
            gap: '1rem',
            animation: 'fadeInUp 1s ease-out 0.6s both'
          }}>
            <div style={{
              width: '40px',
              height: '2px',
              background: 'linear-gradient(45deg, #ff1493, #ff69b4)',
              borderRadius: '2px'
            }}></div>
            <div style={{
              width: '20px',
              height: '2px',
              background: 'linear-gradient(45deg, #da70d6, #ff1493)',
              borderRadius: '2px'
            }}></div>
            <div style={{
              width: '30px',
              height: '2px',
              background: 'linear-gradient(45deg, #ff69b4, #da70d6)',
              borderRadius: '2px'
            }}></div>
          </div>
        </div>

        {/* Panel derecho - Formulario */}
        <div style={{
          flex: '1',
          padding: window.innerWidth <= 768 ? '2rem' : '4rem 3rem',
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'center',
          background: 'rgba(25, 25, 25, 0.8)',
          position: 'relative'
        }}>
          
          {/* Encabezado del formulario */}
          <div style={{
            marginBottom: '2.5rem',
            textAlign: 'center'
          }}>
            <h2 style={{
              fontSize: '2rem',
              marginBottom: '0.5rem',
              color: '#fff',
              fontFamily: 'Georgia, serif'
            }}>
              Iniciar Sesión
            </h2>
            <p style={{
              color: '#ff69b4',
              fontSize: '0.95rem',
              opacity: 0.9
            }}>
              🔐 Accede a tu cuenta Shhhh
            </p>
          </div>

          <form onSubmit={handleSubmit} style={{ width: '100%' }}>
            
            {/* Campo Email */}
            <div style={{ marginBottom: '1.5rem' }}>
              <label 
                htmlFor="email"
                style={{
                  display: 'block',
                  marginBottom: '0.5rem',
                  color: '#ff69b4',
                  fontSize: '0.95rem',
                  fontWeight: '500'
                }}
              >
                💌 Correo Electrónico
              </label>
              <input
                type="email"
                id="email"
                name="email"
                value={formData.email}
                onChange={handleInputChange}
                placeholder="tucorreo@ejemplo.com"
                required
                disabled={loading}
                style={{
                  width: '100%',
                  padding: '1rem 1.2rem',
                  borderRadius: '12px',
                  border: '2px solid rgba(255, 20, 147, 0.3)',
                  backgroundColor: 'rgba(30, 30, 30, 0.8)',
                  color: '#fff',
                  fontSize: '1rem',
                  transition: 'all 0.3s ease',
                  backdropFilter: 'blur(10px)'
                }}
                onFocus={(e) => {
                  e.target.style.borderColor = '#ff69b4';
                  e.target.style.boxShadow = '0 0 20px rgba(255, 105, 180, 0.3)';
                }}
                onBlur={(e) => {
                  e.target.style.borderColor = 'rgba(255, 20, 147, 0.3)';
                  e.target.style.boxShadow = 'none';
                }}
              />
            </div>

            {/* Campo Contraseña */}
            <div style={{ marginBottom: '2rem' }}>
              <label 
                htmlFor="password"
                style={{
                  display: 'block',
                  marginBottom: '0.5rem',
                  color: '#ff69b4',
                  fontSize: '0.95rem',
                  fontWeight: '500'
                }}
              >
                🔑 Contraseña
              </label>
              <input
                type="password"
                id="password"
                name="password"
                value={formData.password}
                onChange={handleInputChange}
                placeholder="••••••••"
                required
                disabled={loading}
                style={{
                  width: '100%',
                  padding: '1rem 1.2rem',
                  borderRadius: '12px',
                  border: '2px solid rgba(255, 20, 147, 0.3)',
                  backgroundColor: 'rgba(30, 30, 30, 0.8)',
                  color: '#fff',
                  fontSize: '1rem',
                  transition: 'all 0.3s ease',
                  backdropFilter: 'blur(10px)'
                }}
                onFocus={(e) => {
                  e.target.style.borderColor = '#ff69b4';
                  e.target.style.boxShadow = '0 0 20px rgba(255, 105, 180, 0.3)';
                }}
                onBlur={(e) => {
                  e.target.style.borderColor = 'rgba(255, 20, 147, 0.3)';
                  e.target.style.boxShadow = 'none';
                }}
              />
            </div>

            {/* Botón de envío */}
            <button
              type="submit"
              disabled={loading}
              className="sparkle"
              style={{
                width: '100%',
                padding: '1.2rem',
                borderRadius: '15px',
                border: 'none',
                background: loading 
                  ? 'rgba(100, 100, 100, 0.5)' 
                  : 'linear-gradient(45deg, #ff1493, #ff69b4, #da70d6)',
                color: '#fff',
                fontSize: '1.1rem',
                fontWeight: 'bold',
                cursor: loading ? 'not-allowed' : 'pointer',
                transition: 'all 0.4s ease',
                boxShadow: loading 
                  ? 'none' 
                  : '0 15px 35px rgba(255, 20, 147, 0.4)',
                backdropFilter: 'blur(10px)',
                textTransform: 'none',
                letterSpacing: '0.5px'
              }}
              onMouseOver={(e) => {
                if (!loading) {
                  e.target.style.transform = 'translateY(-3px) scale(1.02)';
                  e.target.style.boxShadow = '0 20px 45px rgba(255, 20, 147, 0.6)';
                  e.target.style.background = 'linear-gradient(45deg, #ff69b4, #da70d6, #ff1493)';
                }
              }}
              onMouseOut={(e) => {
                if (!loading) {
                  e.target.style.transform = 'translateY(0) scale(1)';
                  e.target.style.boxShadow = '0 15px 35px rgba(255, 20, 147, 0.4)';
                  e.target.style.background = 'linear-gradient(45deg, #ff1493, #ff69b4, #da70d6)';
                }
              }}
            >
              {loading ? (
                <span style={{ 
                  display: 'flex', 
                  alignItems: 'center', 
                  justifyContent: 'center', 
                  gap: '0.8rem' 
                }}>
                  <div style={{
                    width: '20px',
                    height: '20px',
                    border: '2px solid rgba(255, 255, 255, 0.3)',
                    borderTop: '2px solid #fff',
                    borderRadius: '50%',
                    animation: 'spin 1s linear infinite'
                  }}></div>
                  💖 Ingresando...
                </span>
              ) : (
                '✨ Entrar a OswalShop'
              )}
            </button>
          </form>

          {/* Enlaces adicionales */}
          <div style={{
            marginTop: '2rem',
            textAlign: 'center'
          }}>
            <p style={{
              color: '#fff',
              fontSize: '0.95rem',
              marginBottom: '1rem',
              opacity: 0.8
            }}>
              ¿No tienes una cuenta?
            </p>
            <Link
              to="/register"
              style={{
                color: '#ff69b4',
                textDecoration: 'none',
                fontWeight: 'bold',
                fontSize: '1rem',
                padding: '0.8rem 2rem',
                borderRadius: '25px',
                border: '2px solid rgba(255, 105, 180, 0.3)',
                background: 'rgba(255, 105, 180, 0.1)',
                transition: 'all 0.3s ease',
                display: 'inline-block',
                backdropFilter: 'blur(10px)'
              }}
              onMouseOver={(e) => {
                e.target.style.background = 'rgba(255, 105, 180, 0.2)';
                e.target.style.borderColor = '#ff69b4';
                e.target.style.transform = 'translateY(-2px)';
                e.target.style.boxShadow = '0 10px 25px rgba(255, 105, 180, 0.3)';
              }}
              onMouseOut={(e) => {
                e.target.style.background = 'rgba(255, 105, 180, 0.1)';
                e.target.style.borderColor = 'rgba(255, 105, 180, 0.3)';
                e.target.style.transform = 'translateY(0)';
                e.target.style.boxShadow = 'none';
              }}
            >
              💎 Regístrate Aquí
            </Link>
          </div>

          {/* Información adicional */}
          <div style={{
            marginTop: '2rem',
            padding: '1rem',
            background: 'rgba(255, 20, 147, 0.1)',
            borderRadius: '10px',
            border: '1px solid rgba(255, 20, 147, 0.2)',
            textAlign: 'center'
          }}>
            <p style={{
              color: '#ff69b4',
              fontSize: '0.85rem',
              margin: 0,
              opacity: 0.9
            }}>
              🔒 Tu privacidad es nuestra prioridad
            </p>
          </div>
        </div>
      </div>

      {/* Estilos CSS adicionales en el head */}
      <style>
        {`
          @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
          }
          
          @keyframes sparkle {
            0%, 100% { opacity: 0.2; transform: scale(1); }
            50% { opacity: 1; transform: scale(1.2); }
          }
          
          @keyframes pulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.1); }
          }
          
          @keyframes fadeInUp {
            from {
              opacity: 0;
              transform: translateY(30px);
            }
            to {
              opacity: 1;
              transform: translateY(0);
            }
          }
          
          .sparkle:hover {
            animation: sparkle 0.6s ease-in-out;
          }
          
          input::placeholder {
            color: rgba(255, 255, 255, 0.5);
          }
          
          input:disabled {
            opacity: 0.6;
            cursor: not-allowed;
          }
        `}
      </style>
    </div>
  );
};

export default Login;