import React from 'react';

const Footer = () => {
  return (
    <footer style={{
      background: 'rgba(0, 0, 0, 0.8)',
      color: '#fff',
      padding: '3rem 0 1rem',
      textAlign: 'center'
    }}>
      <div style={{
        maxWidth: '1200px',
        margin: '0 auto',
        padding: '0 20px'
      }}>
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
          gap: '2rem',
          marginBottom: '2rem'
        }}>
          <div>
            <h3 style={{ marginBottom: '1rem', color: '#dd06f5ff' }}>SexShop</h3>
            <p style={{ color: '#ccc', lineHeight: 1.8 }}>
              lo que necesitas para el placer, divercion sexo y mas.
            </p>
          </div>
          <div>
            <h3 style={{ marginBottom: '1rem', color: '#e308fcff' }}>Contacto</h3>
            <p style={{ color: '#ccc', lineHeight: 1.8 }}>📞 +57 3652458541</p>
            <p style={{ color: '#ccc', lineHeight: 1.8 }}>mamariarico@SexShop.com</p>
            <p style={{ color: '#ccc', lineHeight: 1.8 }}>Solo ventas Online</p>
          </div>
          <div>
            <h3 style={{ marginBottom: '1rem', color: '#e600ffff' }}>Nuestras redes</h3>
            <p style={{ color: '#ccc', lineHeight: 1.8 }}>
              <a href="https://www.facebook.com/?locale=es_LA" style={{ color: '#ccc', textDecoration: 'none' }}>🗽Facebook</a>
            </p>
            <p style={{ color: '#ccc', lineHeight: 1.8 }}>
              <a href="https://www.instagram.com/" style={{ color: '#ccc', textDecoration: 'none' }}>📷Instagram</a>
            </p>
            <p style={{ color: '#ccc', lineHeight: 1.8 }}>
              <a href="https://x.com/home?lang=es" style={{ color: '#ccc', textDecoration: 'none' }}>✖️ Twitter</a>
            </p>
          </div>
        </div>
        <div style={{
          borderTop: '1px solid #444',
          paddingTop: '1rem',
          color: '#999'
        }}>
          <p>&copy; 2025 SexShop. El mundo que el chamo se merece.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;