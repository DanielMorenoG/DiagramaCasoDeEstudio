import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useCart } from '../context/CartContext';

const Header = () => {
  const { user, logout, isAdmin } = useAuth();
  const { getCartItemsCount } = useCart();
  const navigate = useNavigate();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  return (
    <header style={{
      background: 'linear-gradient(135deg, #1a1a1a 0%, #2d1b3d 50%, #1a1a1a 100%)',
      backdropFilter: 'blur(15px)',
      padding: '1rem 0',
      position: 'fixed',
      width: '100%',
      top: 0,
      zIndex: 1000,
      borderBottom: '2px solid #ff1493',
      boxShadow: '0 4px 20px rgba(255, 20, 147, 0.3)'
    }}>
      <nav style={{
        maxWidth: '1200px',
        margin: '0 auto',
        padding: '0 20px',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        position: 'relative'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '2rem' }}>
          <Link to="/" style={{
            fontSize: window.innerWidth <= 768 ? '1.5rem' : '2.2rem',
            fontWeight: 'bold',
            background: 'linear-gradient(45deg, #ff1493, #ff69b4, #da70d6)',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            backgroundClip: 'text',
            textShadow: '0 0 10px rgba(255, 20, 147, 0.5)',
            textDecoration: 'none',
            fontFamily: 'Georgia, serif',
            letterSpacing: '1px'
          }}>
            💋 SexShop
          </Link>

          {/* Hamburger Menu Button */}
          <button
            onClick={toggleMobileMenu}
            style={{
              display: window.innerWidth <= 768 ? 'block' : 'none',
              background: 'none',
              border: 'none',
              color: '#ff1493',
              fontSize: '1.5rem',
              cursor: 'pointer',
              padding: '0.5rem',
              marginLeft: 'auto'
            }}
          >
            ☰
          </button>
          
          <ul style={{
            display: window.innerWidth <= 768 ? 'none' : 'flex',
            listStyle: 'none',
            gap: '2rem',
            margin: 0,
            padding: 0
          }}>
            <li>
              <Link to="/" style={{
                color: '#fff',
                textDecoration: 'none',
                fontWeight: 500,
                padding: '0.8rem 1.5rem',
                borderRadius: '30px',
                transition: 'all 0.3s ease',
                background: 'rgba(255, 20, 147, 0.1)',
                border: '1px solid rgba(255, 20, 147, 0.3)'
              }}
              onMouseOver={(e) => {
                e.target.style.background = 'rgba(255, 20, 147, 0.3)';
                e.target.style.transform = 'translateY(-2px)';
                e.target.style.boxShadow = '0 5px 15px rgba(255, 20, 147, 0.4)';
              }}
              onMouseOut={(e) => {
                e.target.style.background = 'rgba(255, 20, 147, 0.1)';
                e.target.style.transform = 'translateY(0)';
                e.target.style.boxShadow = 'none';
              }}>
                🏠 Inicio
              </Link>
            </li>
            <li>
              <Link to="/products" style={{
                color: '#fff',
                textDecoration: 'none',
                fontWeight: 500,
                padding: '0.8rem 1.5rem',
                borderRadius: '30px',
                transition: 'all 0.3s ease',
                background: 'rgba(255, 20, 147, 0.1)',
                border: '1px solid rgba(255, 20, 147, 0.3)'
              }}
              onMouseOver={(e) => {
                e.target.style.background = 'rgba(255, 20, 147, 0.3)';
                e.target.style.transform = 'translateY(-2px)';
                e.target.style.boxShadow = '0 5px 15px rgba(255, 20, 147, 0.4)';
              }}
              onMouseOut={(e) => {
                e.target.style.background = 'rgba(255, 20, 147, 0.1)';
                e.target.style.transform = 'translateY(0)';
                e.target.style.boxShadow = 'none';
              }}>
                🛍️ Productos
              </Link>
            </li>
            {user && (
              <li>
                <Link to="/cart" style={{
                  color: '#fff',
                  textDecoration: 'none',
                  fontWeight: 500,
                  padding: '0.8rem 1.5rem',
                  borderRadius: '30px',
                  transition: 'all 0.3s ease',
                  position: 'relative',
                  background: 'rgba(255, 20, 147, 0.1)',
                  border: '1px solid rgba(255, 20, 147, 0.3)'
                }}
                onMouseOver={(e) => {
                  e.target.style.background = 'rgba(255, 20, 147, 0.3)';
                  e.target.style.transform = 'translateY(-2px)';
                  e.target.style.boxShadow = '0 5px 15px rgba(255, 20, 147, 0.4)';
                }}
                onMouseOut={(e) => {
                  e.target.style.background = 'rgba(255, 20, 147, 0.1)';
                  e.target.style.transform = 'translateY(0)';
                  e.target.style.boxShadow = 'none';
                }}>
                  🛒 Carrito
                  {getCartItemsCount() > 0 && (
                    <span style={{
                      position: 'absolute',
                      top: '-8px',
                      right: '-8px',
                      background: 'linear-gradient(45deg, #ff1493, #ff69b4)',
                      color: 'white',
                      borderRadius: '50%',
                      padding: '4px 8px',
                      fontSize: '0.8rem',
                      minWidth: '20px',
                      textAlign: 'center',
                      fontWeight: 'bold',
                      boxShadow: '0 2px 10px rgba(255, 20, 147, 0.6)',
                      animation: 'pulse 2s infinite'
                    }}>
                      {getCartItemsCount()}
                    </span>
                  )}
                </Link>
              </li>
            )}
            {isAdmin() && (
              <li>
                <Link to="/admin" style={{
                  color: '#fff',
                  textDecoration: 'none',
                  fontWeight: 500,
                  padding: '0.8rem 1.5rem',
                  borderRadius: '30px',
                  transition: 'all 0.3s ease',
                  background: 'linear-gradient(45deg, #8a2be2, #9932cc)',
                  border: '1px solid #8a2be2',
                  boxShadow: '0 3px 10px rgba(138, 43, 226, 0.4)'
                }}
                onMouseOver={(e) => {
                  e.target.style.background = 'linear-gradient(45deg, #9932cc, #8a2be2)';
                  e.target.style.transform = 'translateY(-2px)';
                  e.target.style.boxShadow = '0 5px 15px rgba(138, 43, 226, 0.6)';
                }}
                onMouseOut={(e) => {
                  e.target.style.background = 'linear-gradient(45deg, #8a2be2, #9932cc)';
                  e.target.style.transform = 'translateY(0)';
                  e.target.style.boxShadow = '0 3px 10px rgba(138, 43, 226, 0.4)';
                }}>
                  ⚙️ Admin
                </Link>
              </li>
            )}
          </ul>
        </div>

        <div style={{ 
          display: window.innerWidth <= 768 ? 'none' : 'flex', 
          gap: '1rem', 
          alignItems: 'center' 
        }}>
          {user ? (
            <>
              <span style={{
                color: '#ff69b4',
                padding: '0.8rem 1.5rem',
                background: 'rgba(255, 105, 180, 0.1)',
                borderRadius: '30px',
                fontSize: '0.9rem',
                border: '1px solid rgba(255, 105, 180, 0.3)',
                fontWeight: '500'
              }}>
                💖 ¡Hola, {user.name}!
              </span>
              <button
                onClick={handleLogout}
                style={{
                  padding: '0.8rem 1.5rem',
                  fontSize: '1rem',
                  fontWeight: 'bold',
                  border: '2px solid #ff1493',
                  borderRadius: '30px',
                  cursor: 'pointer',
                  background: 'transparent',
                  color: '#ff1493',
                  transition: 'all 0.3s ease'
                }}
                onMouseOver={(e) => {
                  e.target.style.background = 'linear-gradient(45deg, #ff1493, #ff69b4)';
                  e.target.style.color = '#fff';
                  e.target.style.transform = 'translateY(-2px)';
                  e.target.style.boxShadow = '0 5px 15px rgba(255, 20, 147, 0.4)';
                }}
                onMouseOut={(e) => {
                  e.target.style.background = 'transparent';
                  e.target.style.color = '#ff1493';
                  e.target.style.transform = 'translateY(0)';
                  e.target.style.boxShadow = 'none';
                }}
              >
                Cerrar Sesión
              </button>
            </>
          ) : (
            <>
              <Link to="/login">
                <button style={{
                  padding: '0.8rem 1.5rem',
                  fontSize: '1rem',
                  fontWeight: 500,
                  border: '2px solid #ff1493',
                  borderRadius: '30px',
                  cursor: 'pointer',
                  background: 'transparent',
                  color: '#ff1493',
                  transition: 'all 0.3s ease',
                  textDecoration: 'none'
                }}
                onMouseOver={(e) => {
                  e.target.style.background = 'rgba(255, 20, 147, 0.1)';
                  e.target.style.transform = 'translateY(-2px)';
                  e.target.style.boxShadow = '0 5px 15px rgba(255, 20, 147, 0.3)';
                }}
                onMouseOut={(e) => {
                  e.target.style.background = 'transparent';
                  e.target.style.transform = 'translateY(0)';
                  e.target.style.boxShadow = 'none';
                }}>
                  Iniciar Sesión
                </button>
              </Link>
              <Link to="/register">
                <button style={{
                  padding: '0.8rem 1.5rem',
                  fontSize: '1rem',
                  fontWeight: 'bold',
                  border: 'none',
                  borderRadius: '30px',
                  cursor: 'pointer',
                  background: 'linear-gradient(45deg, #ff1493, #ff69b4, #da70d6)',
                  color: '#fff',
                  transition: 'all 0.3s ease',
                  boxShadow: '0 8px 20px rgba(255, 20, 147, 0.4)'
                }}
                onMouseOver={(e) => {
                  e.target.style.background = 'linear-gradient(45deg, #ff69b4, #da70d6, #ff1493)';
                  e.target.style.transform = 'translateY(-3px)';
                  e.target.style.boxShadow = '0 10px 25px rgba(255, 20, 147, 0.6)';
                }}
                onMouseOut={(e) => {
                  e.target.style.background = 'linear-gradient(45deg, #ff1493, #ff69b4, #da70d6)';
                  e.target.style.transform = 'translateY(0)';
                  e.target.style.boxShadow = '0 8px 20px rgba(255, 20, 147, 0.4)';
                }}>
                  💕 Registrarse
                </button>
              </Link>
            </>
          )}
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div style={{
            position: 'absolute',
            top: '100%',
            left: 0,
            right: 0,
            background: 'linear-gradient(135deg, #1a1a1a 0%, #2d1b3d 50%, #1a1a1a 100%)',
            borderTop: '2px solid #ff1493',
            borderBottom: '2px solid #ff1493',
            boxShadow: '0 4px 20px rgba(255, 20, 147, 0.3)',
            zIndex: 999,
            display: window.innerWidth <= 768 ? 'block' : 'none'
          }}>
            <div style={{
              padding: '1rem',
              display: 'flex',
              flexDirection: 'column',
              gap: '1rem'
            }}>
              {/* Mobile Navigation Links */}
              <Link 
                to="/" 
                onClick={() => setIsMobileMenuOpen(false)}
                style={{
                  color: '#fff',
                  textDecoration: 'none',
                  fontWeight: 500,
                  padding: '0.8rem 1.5rem',
                  borderRadius: '30px',
                  background: 'rgba(255, 20, 147, 0.1)',
                  border: '1px solid rgba(255, 20, 147, 0.3)',
                  textAlign: 'center',
                  transition: 'all 0.3s ease'
                }}
              >
                🏠 Inicio
              </Link>
              
              <Link 
                to="/products" 
                onClick={() => setIsMobileMenuOpen(false)}
                style={{
                  color: '#fff',
                  textDecoration: 'none',
                  fontWeight: 500,
                  padding: '0.8rem 1.5rem',
                  borderRadius: '30px',
                  background: 'rgba(255, 20, 147, 0.1)',
                  border: '1px solid rgba(255, 20, 147, 0.3)',
                  textAlign: 'center',
                  transition: 'all 0.3s ease'
                }}
              >
                🛍️ Productos
              </Link>

              {user && (
                <Link 
                  to="/cart" 
                  onClick={() => setIsMobileMenuOpen(false)}
                  style={{
                    color: '#fff',
                    textDecoration: 'none',
                    fontWeight: 500,
                    padding: '0.8rem 1.5rem',
                    borderRadius: '30px',
                    background: 'rgba(255, 20, 147, 0.1)',
                    border: '1px solid rgba(255, 20, 147, 0.3)',
                    textAlign: 'center',
                    position: 'relative',
                    transition: 'all 0.3s ease'
                  }}
                >
                  🛒 Carrito
                  {getCartItemsCount() > 0 && (
                    <span style={{
                      position: 'absolute',
                      top: '5px',
                      right: '15px',
                      background: 'linear-gradient(45deg, #ff1493, #ff69b4)',
                      color: 'white',
                      borderRadius: '50%',
                      padding: '2px 6px',
                      fontSize: '0.8rem',
                      minWidth: '18px',
                      textAlign: 'center',
                      fontWeight: 'bold'
                    }}>
                      {getCartItemsCount()}
                    </span>
                  )}
                </Link>
              )}

              {isAdmin() && (
                <Link 
                  to="/admin" 
                  onClick={() => setIsMobileMenuOpen(false)}
                  style={{
                    color: '#fff',
                    textDecoration: 'none',
                    fontWeight: 500,
                    padding: '0.8rem 1.5rem',
                    borderRadius: '30px',
                    background: 'linear-gradient(45deg, #8a2be2, #9932cc)',
                    border: '1px solid #8a2be2',
                    textAlign: 'center',
                    transition: 'all 0.3s ease'
                  }}
                >
                  ⚙️ Admin
                </Link>
              )}

              {/* Mobile User Actions */}
              {user ? (
                <div style={{
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '0.5rem',
                  marginTop: '1rem',
                  paddingTop: '1rem',
                  borderTop: '1px solid rgba(255, 20, 147, 0.3)'
                }}>
                  <span style={{
                    color: '#ff69b4',
                    padding: '0.8rem 1.5rem',
                    background: 'rgba(255, 105, 180, 0.1)',
                    borderRadius: '30px',
                    fontSize: '0.9rem',
                    border: '1px solid rgba(255, 105, 180, 0.3)',
                    fontWeight: '500',
                    textAlign: 'center'
                  }}>
                    💖 ¡Hola, {user.name}!
                  </span>
                  <button
                    onClick={() => {
                      handleLogout();
                      setIsMobileMenuOpen(false);
                    }}
                    style={{
                      padding: '0.8rem 1.5rem',
                      fontSize: '1rem',
                      fontWeight: 'bold',
                      border: '2px solid #ff1493',
                      borderRadius: '30px',
                      cursor: 'pointer',
                      background: 'transparent',
                      color: '#ff1493',
                      transition: 'all 0.3s ease'
                    }}
                  >
                    Cerrar Sesión
                  </button>
                </div>
              ) : (
                <div style={{
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '0.5rem',
                  marginTop: '1rem',
                  paddingTop: '1rem',
                  borderTop: '1px solid rgba(255, 20, 147, 0.3)'
                }}>
                  <Link 
                    to="/login" 
                    onClick={() => setIsMobileMenuOpen(false)}
                  >
                    <button style={{
                      width: '100%',
                      padding: '0.8rem 1.5rem',
                      fontSize: '1rem',
                      fontWeight: 500,
                      border: '2px solid #ff1493',
                      borderRadius: '30px',
                      cursor: 'pointer',
                      background: 'transparent',
                      color: '#ff1493',
                      transition: 'all 0.3s ease'
                    }}>
                      Iniciar Sesión
                    </button>
                  </Link>
                  
                  <Link 
                    to="/register" 
                    onClick={() => setIsMobileMenuOpen(false)}
                  >
                    <button style={{
                      width: '100%',
                      padding: '0.8rem 1.5rem',
                      fontSize: '1rem',
                      fontWeight: 'bold',
                      border: 'none',
                      borderRadius: '30px',
                      cursor: 'pointer',
                      background: 'linear-gradient(45deg, #ff1493, #ff69b4, #da70d6)',
                      color: '#fff',
                      transition: 'all 0.3s ease',
                      boxShadow: '0 8px 20px rgba(255, 20, 147, 0.4)'
                    }}>
                      💕 Registrarse
                    </button>
                  </Link>
                </div>
              )}
            </div>
          </div>
        )}
      </nav>
      
      <style jsx>{`
        @keyframes pulse {
          0% { transform: scale(1); }
          50% { transform: scale(1.1); }
          100% { transform: scale(1); }
        }

        /* Media Queries for better responsiveness */
        @media (max-width: 768px) {
          .logo-text {
            font-size: 1.5rem !important;
          }
          
          .nav-button {
            padding: 0.6rem 1rem !important;
            font-size: 0.9rem !important;
          }
          
          .mobile-menu-item:hover {
            background: rgba(255, 20, 147, 0.3) !important;
            transform: scale(1.02) !important;
          }
        }

        @media (max-width: 480px) {
          .logo-text {
            font-size: 1.2rem !important;
          }
          
          header {
            padding: 0.8rem 0 !important;
          }
          
          nav {
            padding: 0 15px !important;
          }
        }

        /* Smooth transitions for mobile menu */
        .mobile-menu {
          animation: slideDown 0.3s ease-out;
        }

        @keyframes slideDown {
          from {
            opacity: 0;
            transform: translateY(-10px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
      `}</style>
    </header>
  );
};

export default Header;